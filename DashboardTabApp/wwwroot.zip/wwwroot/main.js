(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-course-dialog/add-course-dialog.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-course-dialog/add-course-dialog.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1 mat-dialog-title>Select Course</h1>\n<div mat-dialog-content>\n    <p>Select from an existing team.</p>\n</div>\n<div>\n    <mat-form-field>\n        <mat-select [(ngModel)]=\"selectedCourse\">\n            <mat-option *ngFor=\"let obj of data\" [value]=\"obj\">\n                {{obj.displayName}}\n            </mat-option>\n        </mat-select>\n    </mat-form-field>\n</div>\n<div mat-dialog-actions>\n    <button mat-button (click)=\"onOkClick()\">OK</button>\n    <button mat-button (click)=\"onCancelClick()\">Cancel</button>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng4-loading-spinner> </ng4-loading-spinner>\n<div class='container-fluid'>\n    <div class='row'>\n        <div class='col-sm-3'>\n            <nav-menu></nav-menu>\n        </div>\n        <div class='col-sm-9 body-content'>\n            <router-outlet></router-outlet>\n        </div>\n    </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/config/config.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/config/config.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1>Hello!</h1>\n<p>All ready to go! Click save to proceed.</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.html":
/*!**************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.html ***!
  \**************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1>\n    Course Provisioning Information\n</h1>\n\n<div>\n    <h2>Table field details</h2>\n    <img src=\"../../assets/course info.png\" style=\"padding-bottom:10px\" />\n    <ul>\n        <li><b>PredictiveQnAServiceHost:</b> Host property + “/” when the QnA maker is published. <sup>1</sup></li>\n        <li><b>PredictiveQnAKnowledgeBaseId:</b>  GUID part of the POST command</li>\n        <li><b>PredictiveQnAEndpointKey:</b>  GUID part of Authorization.</li>\n        <li><b>PredictiveQnAHttpEndpoint:</b>  Endpoint of the Cognitive Service.</li>\n        <li><b>PredictiveQnAHttpKey:</b>  Key of the Cognitive Service.</li>\n        <li><b>PredictiveQnAKnowledgeBaseName:</b>  Name of knowledgebase for the course on QnA Maker.</li>\n        <li><b>PredictiveQnAConfidenceThreshold:</b>  Integer that should be from 0-100 that reflects the confidence percentage an answer from QnA Maker must be if it is to be supplied as an answer to a question.</li>\n    </ul>\n</div>\n\n<div mat-dialog-actions style=\"padding-bottom:10px\">\n    <button mat-raised-button (click)=\"onOKClick()\">OK</button>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/courseadmin/courseadmin.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courseadmin/courseadmin.component.html ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1>Course Admin</h1>\n<a target=\"_blank\" routerLink=\"/courseinfo\">Course provisioning instructions</a>\n<div style=\"padding-bottom:5px\">\n    <button mat-raised-button (click)=\"addRow()\">\n        <mat-icon>add</mat-icon> New Course\n    </button>\n</div>\n<div style=\"padding-bottom:20px\">\n    <mat-table #table [dataSource]=\"dataSource\">\n\n        <ng-container matColumnDef=\"courseName\">\n            <mat-header-cell *matHeaderCellDef>Course Name </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <span>{{course.name}}</span>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"predictiveQnAServiceHost\">\n            <mat-header-cell *matHeaderCellDef>Service Host </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"Service Host\" [value]=\"course.predictiveQnAServiceHost\" [(ngModel)]=\"course.predictiveQnAServiceHost\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"predictiveQnAKnowledgeBaseId\">\n            <mat-header-cell *matHeaderCellDef>KnowledgeBase Id </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"KnowledgeBase Id\" [value]=\"course.predictiveQnAKnowledgeBaseId\" [(ngModel)]=\"course.predictiveQnAKnowledgeBaseId\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"predictiveQnAEndpointKey\">\n            <mat-header-cell *matHeaderCellDef>Endpoint Key </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"Endpoint Key\" [value]=\"course.predictiveQnAEndpointKey\" [(ngModel)]=\"course.predictiveQnAEndpointKey\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"predictiveQnAHttpEndpoint\">\n            <mat-header-cell *matHeaderCellDef>Http Endpoint </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"Http Endpoint\" [value]=\"course.predictiveQnAHttpEndpoint\" [(ngModel)]=\"course.predictiveQnAHttpEndpoint\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"predictiveQnAHttpKey\">\n            <mat-header-cell *matHeaderCellDef>Http Key </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"Http Key\" [value]=\"course.predictiveQnAHttpKey\" [(ngModel)]=\"course.predictiveQnAHttpKey\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"predictiveQnAKnowledgeBaseName\">\n            <mat-header-cell *matHeaderCellDef>KnowledgeBase Name </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"KnowledgeBase Name\" [value]=\"course.predictiveQnAKnowledgeBaseName\" [(ngModel)]=\"course.predictiveQnAKnowledgeBaseName\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"predictiveQnAConfidenceThreshold\">\n            <mat-header-cell *matHeaderCellDef>Confidence Threshold </mat-header-cell>\n            <mat-cell *matCellDef=\"let course\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"Confidence Threshold\" [value]=\"course.predictiveQnAConfidenceThreshold\" [(ngModel)]=\"course.predictiveQnAConfidenceThreshold\" style=\"text-align:center\" type=\"number\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"deleteButton\">\n            <mat-header-cell class=\"lastColumn\" *matHeaderCellDef></mat-header-cell>\n            <mat-cell class=\"lastColumn\" *matCellDef=\"let course; let i = index;\">\n                <button mat-button (click)=\"deleteRow(i)\"><mat-icon>delete</mat-icon></button>\n                <button mat-button (click)=\"saveRow(course)\"><mat-icon>save</mat-icon></button>\n            </mat-cell>\n        </ng-container>\n\n\n        <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\n        <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\n    </mat-table>\n</div>\n\n<div>\n    <span> </span>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/delete-course-dialog/delete-course-dialog.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/delete-course-dialog/delete-course-dialog.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1 mat-dialog-title>Delete Course</h1>\n<div mat-dialog-content>\n    <p>Are you sure you want to delete {{courseData.courseName}}?</p>\n</div>\n<div mat-dialog-actions>\n    <button mat-button (click)=\"onYesClick()\">Yes</button>\n    <button mat-button (click)=\"onNoClick()\">No</button>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/generic-dialog/generic-dialog.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/generic-dialog/generic-dialog.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1 mat-dialog-title>{{data.outcome}}</h1>\n<div mat-dialog-content>\n    <p>{{data.message}}</p>\n</div>\n<div mat-dialog-actions>\n    <button mat-button (click)=\"onNoClick()\">OK</button>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<br/>\n<br/>\n<h2 *ngIf=\"authService.showSignInButton\" >Please sign in to continue</h2>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/mystudents/mystudents.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/mystudents/mystudents.component.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h3>My Students</h3>\n<p>Demonstrator dashboard to see their students data</p>\n\n\n<p> Your tutorial group(s):</p>\n<div id=\"myBtnContainer\">\n    <button [ngClass]=\"{'btn classFilterBtn' : true,'active': selectedTutorial === 'ALL'}\" (click)=\"filterByCode('ALL')\"> Show all</button>\n    <button [ngClass]=\"{'btn classFilterBtn' : true,'active': selectedTutorial === tutorial.code}\" *ngFor=\"let tutorial of currentUser.tutorialGroups\" (click)=\"filterByCode(tutorial.code)\">{{tutorial.code}}</button>\n</div>\n\n<tabs>\n    <tab tabTitle=\"Unanswered Questions\" tabActive=\"true\">\n        <div id=\"unansweredCardDiv\" class=\"cardDiv card-body\">\n        </div>\n    </tab>\n    <tab tabTitle=\"Answered Questions\">\n        <div id=\"answeredCardDiv\" class=\"cardDiv card-body\">\n        </div>\n    </tab>\n</tabs>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/navmenu/navmenu.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/navmenu/navmenu.component.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class='main-nav'>\n    <div class='navbar navbar-inverse' style=\"display: block;\">\n        <div class='navbar-header'>\n            <p class='navbar-brand teamsTitle'>Question Dashboard</p>\n        </div>\n\n        <div *ngIf=\"errorMessage\" style=\"color:red\">{{errorMessage}}</div>\n        \n        <div class='navbar-collapse collapse'>\n            <ul class='nav navbar-nav'>\n                <li *ngFor=\"let team of teamGroupDetail\" [routerLinkActive]=\"['link-active']\">\n                    <a routerLink=\"/question/{{team.id}}\" (click)=\"teamNav(team.id)\" class=\"teamsText navtext\">\n                        <span class=\"nav-icon\">\n                            <img [src]=\"team.safePhotoByteUrl\" width=\"32\" height=\"32\" />\n                        </span>\n                        {{team.displayName}}\n                    </a>\n                </li>\n                <li *ngIf=\"(isLecturer || isDemonstrator ||isAdmin)&& authService.loggedIn\" [routerLinkActive]=\"['link-active']\">\n                    <a [routerLink]=\"['/courseadmin']\" (click)=\"courseAdminNav()\" class=\"teamsText navtext\">\n                        <fa-icon [icon]=\"faChalkboardTeacher\" size=\"2x\"></fa-icon>Course Admin\n                    </a>\n                </li>\n                <li *ngIf=\"(isLecturer || isDemonstrator ||isAdmin)&& authService.loggedIn\" [routerLinkActive]=\"['link-active']\">\n                    <a [routerLink]=\"['/app-useradmin']\" (click)=\"addStudentNav()\" class=\"teamsText navtext\">\n                        <fa-icon [icon]=\"faUsersCog\" size=\"2x\"></fa-icon>User Admin\n                    </a>\n                </li>\n                <li *ngIf=\"(isLecturer || isDemonstrator ||isAdmin)&& authService.loggedIn\" [routerLinkActive]=\"['link-active']\">\n                    <a [routerLink]=\"['/tutorialadmin']\" (click)=\"tutorialAdminNav()\" class=\"teamsText navtext\">\n                        <fa-icon [icon]=\"faUserFriends\" size=\"2x\"></fa-icon>Tutorial Admin\n                    </a>\n                </li>\n                <li *ngIf=\"(isLecturer || isDemonstrator ||isAdmin)&& authService.loggedIn\" [routerLinkActive]=\"['link-active']\" #MyStudentsActive=\"routerLinkActive\">\n                    <a [routerLink]=\"['/mystudents']\" (click)=\"myStudentNav()\" class=\"teamsText navtext\">\n                        <fa-icon [icon]=\"faUsers\" size=\"2x\"></fa-icon>My Students\n                    </a>\n                </li>\n                <li *ngIf=\"!authService.loggedIn\" [routerLinkActive]=\"['link-active']\">\n                    <a (click)=\"authService.signIn()\" class=\"teamsText navtext\">\n                        <fa-icon [icon]=\"faSignInAlt\" size=\"2x\"></fa-icon>Sign In\n                    </a>\n                </li>\n                <!--<li *ngIf=\"authService.loggedIn\" [routerLinkActive]=\"['link-active']\">\n                    <a (click)=\"authService.signOut()\" class=\"teamsText navtext\">\n                        <fa-icon [icon]=\"faSignInAlt\" size=\"2x\"></fa-icon>Sign Out\n                    </a>\n                </li>-->\n            </ul>\n        </div>\n    </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/question/question.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/question/question.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1> </h1>\n\n<!--<p> Hello {{currentUser.fullName}}!</p>-->\n\n<div id=\"mainFilterContainer\">\n    <button class=\"filterCollapseButton teamsText\" (click)=\"showHideContent($event)\">\n        <i [className]=\"plusminus_classname\"></i>\n        Filters\n    </button>\n    <div *ngIf=\"filterContentVisible\" class=\"filterCollapseContent\">\n        <form class=\"container-fluid\" name=\"questionForm\" #questionForm=\"ngForm\">\n            <div class=\"form-group\">\n                <label class=\"teamsText\" for=\"questionTopic\">Topic</label>\n                <select class=\"form-control dropdown teamsText\" #questionTopic=\"ngModel\" name=\"questionTopic\" [(ngModel)]=\"selectedTopic\">\n                    <option *ngFor=\"let t of topics\" [ngValue]=\"t\">{{t}}</option>\n                </select>\n            </div>\n\n            <!--<div class=\"form-group\">\n                <label class=\"teamsText\" for=\"questionStatus\">Status</label>\n                <select class=\"form-control teamsText\" #questionStatus=\"ngModel\" name=\"questionStatus\" [(ngModel)]=\"selectedStatus\">\n                    <option *ngFor=\"let s of statuses\" [ngValue]=\"s\">{{s}}</option>\n                </select>\n            </div>-->\n\n            <div class=\"filterButton\">\n                <button class=\"teamsText ac-pushButton filterButtonTeamsCustom\" type=\"button\" (click)=\"applyFilters($event)\">Apply Filters</button>\n                <button class=\"teamsText ac-pushButton\" type=\"button\" (click)=\"resetFilters($event)\">Reset Filters</button>\n            </div>\n        </form>\n    </div>\n</div>\n\n<tabs>\n    <tab tabTitle=\"Unanswered Questions\" tabActive=\"true\">\n        <div id=\"unansweredCardDiv\" class=\"cardDiv card-body teamsText\" >\n        </div>\n    </tab>\n    <tab tabTitle=\"Answered Questions\">\n        <div id=\"answeredCardDiv\" class=\"cardDiv card-body teamsText\">\n        </div>\n    </tab>\n</tabs>\n\n<!--<div id=\"cardDiv\"></div>-->\n\n<!--<div class=\"panel-group\" id=\"accordion\">\n    <div class=\"panel panel-default\">\n        <div class=\"panel-heading\" id=\"headingOne\">\n            <h4 class=\"panel-title\">\n                <button class=\"questionsCollapseButton btn btn-link\" data-toggle=\"collapse\" data-target=\"#collapseOne\" (click)=\"showHideUnanswered($event)\">\n                    <i [ngClass]=\"{'plusminus glyphicon': true,'glyphicon-minus': unansweredContentVisible, 'glyphicon-plus': !unansweredContentVisible}\"></i>\n                    Unanswered Questions\n                </button>\n            </h4>\n        </div>\n        <div id=\"collapseOne\" class=\"panel-collapse collapse in\">\n            <div id=\"unansweredCardDiv\" class=\"cardDiv card-body\">\n            </div>\n        </div>\n    </div>\n    <div class=\"panel panel-default\">\n        <div class=\"panel-heading\" id=\"headingTwo\">\n            <h4 class=\"panel-title\">\n                <button class=\"questionsCollapseButton btn btn-link collapsed\" data-toggle=\"collapse\" data-target=\"#collapseTwo\" (click)=\"showHideAnswered($event)\">\n                    <i [ngClass]=\"{'plusminus glyphicon': true,'glyphicon-minus': answeredContentVisible, 'glyphicon-plus': !answeredContentVisible}\"></i>\n                    Answered Questions\n                </button>\n            </h4>\n        </div>\n        <div id=\"collapseTwo\" class=\"panel-collapse collapse in\">\n            <div id=\"answeredCardDiv\" class=\"cardDiv card-body\">\n            </div>\n        </div>\n    </div>\n</div>-->\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-end/silent-end.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/silent-end/silent-end.component.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-start/silent-start.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/silent-start/silent-start.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tutorialadmin/tutorialadmin.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tutorialadmin/tutorialadmin.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1 style=\"padding-bottom:10px\">Tutorial Group Administration</h1>\n<p>\n    Use the table below to administer tutorials by course.\n</p>\n<p>\n    Select a course to begin\n</p>\n\n\n<div>\n    <label style=\"padding-right:5px; font-weight:bold\">Select Course</label>\n    <mat-form-field>\n        <mat-select [(ngModel)]=\"selectedCourseName\" style=\"padding-left:5px\">\n            <mat-option *ngFor=\"let course of courseList\" [value]=\"course.name\" (onSelectionChange)=\"updateTutorialMappingTable(course)\">\n                {{course.name}}\n            </mat-option>\n        </mat-select>\n    </mat-form-field>\n</div>\n\n<div style=\"padding-bottom:5px\" *ngIf=\"selectedCourseName != undefined\">\n    <button mat-raised-button (click)=\"addRow()\">\n        <mat-icon>add</mat-icon> New Tutorial\n    </button>\n</div>\n<div style=\"padding-bottom:20px; padding-top:10px\">\n    <mat-table #table [dataSource]=\"dataSource\">\n\n        <ng-container matColumnDef=\"tutorialcode\">\n            <mat-header-cell class=\"firstColumnTutorial\" *matHeaderCellDef>Tutorial Code</mat-header-cell>\n            <mat-cell class=\"firstColumnTutorial\" *matCellDef=\"let tutorial\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"Tutorial Code\" [value]=\"tutorial.code\" [(ngModel)]=\"tutorial.code\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"name\">\n            <mat-header-cell class=\"innerColumnTutorial\" *matHeaderCellDef>Tutorial Name </mat-header-cell>\n            <mat-cell class=\"innerColumnTutorial\" *matCellDef=\"let tutorial\">\n                <mat-form-field floatLabel=\"never\">\n                    <input matInput placeholder=\"Tutorial Name\" [value]=\"tutorial.name\" [(ngModel)]=\"tutorial.name\">\n                </mat-form-field>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"actions\">\n            <mat-header-cell class=\"lastColumnTutorial\" *matHeaderCellDef>Actions</mat-header-cell>\n            <mat-cell class=\"lastColumnTutorial\" *matCellDef=\"let tutorial; let i = index;\">\n                <button mat-button (click)=\"deleteRow(tutorial, i)\"><mat-icon>delete</mat-icon></button>\n                <button mat-button (click)=\"saveRow(i)\"><mat-icon>save</mat-icon></button>\n            </mat-cell>\n        </ng-container>\n\n\n        <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\n        <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\n    </mat-table>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/user-tutorial-dialog/user-tutorial-dialog.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-tutorial-dialog/user-tutorial-dialog.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1>{{user.fullName}}</h1>\n<div mat-dialog-content>\n    <p>Select/remove tutorials for this user.</p>\n</div>\n<form [formGroup]=\"tutorialForm\">\n    <div>\n        <mat-selection-list formControlName=\"tutorials\"  [(ngModel)]=\"selectedTutorials\">\n            <mat-list-option *ngFor=\"let tutorial of tutorials; let i = index\" [selected]=\"data.user.tutorialGroups[i]!=undefined ? data.user.tutorialGroups[i].id == (tutorial.id): false\" [value]=\"tutorial\">\n                {{tutorial.code + \" \" + tutorial.name}}\n            </mat-list-option>\n        </mat-selection-list>\n    </div>\n</form>\n<div mat-dialog-actions>\n    <button mat-button (click)=\"onOkClick()\">OK</button>\n    <button mat-button (click)=\"onCancelClick()\">Cancel</button>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/useradmin/useradmin.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/useradmin/useradmin.component.html ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1 style=\"padding-bottom:10px\">User Administration</h1>\n<div>\n    <label style=\"padding-right:5px; font-weight:bold\">Select Course</label>\n    <mat-form-field>\n        <mat-select [(ngModel)]=\"selectedCourseName\" style=\"padding-left:5px\" (ngModelChange)=\"updateUserTable($event)\" >\n            <mat-option *ngFor=\"let course of courseList\" [value]=\"course\" >\n                {{course.name}}\n            </mat-option>\n        </mat-select>\n    </mat-form-field>\n</div>\n\n\n<div style=\"padding-bottom:5px\" *ngIf=\"selectedCourseName != undefined\">\n    <button mat-raised-button (click)=\"refreshUsers()\">\n        <img src=\"../../assets/favicon.ico\" style=\"width:24px;height:24px;padding-right:5px\" /> Sync Users From Teams\n    </button>\n</div>\n<div style=\"padding-bottom:20px; padding-top:10px\">\n    <mat-table #table [dataSource]=\"dataSource\">\n\n        <ng-container matColumnDef=\"userName\">\n            <mat-header-cell class=\"firstColumn\" *matHeaderCellDef>Username </mat-header-cell>\n            <mat-cell class=\"firstColumn\" *matCellDef=\"let user\">\n                <span>{{user.userName}}</span>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"firstName\">\n            <mat-header-cell class=\"innerColumns\" *matHeaderCellDef>First Name </mat-header-cell>\n            <mat-cell class=\"innerColumns\" *matCellDef=\"let user\">\n                <span>{{user.firstName}}</span>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"lastName\">\n            <mat-header-cell class=\"innerColumns\" *matHeaderCellDef>Last Name </mat-header-cell>\n            <mat-cell class=\"innerColumns\" *matCellDef=\"let user\">\n                <span>{{user.lastName}}</span>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"role\">\n            <mat-header-cell class=\"innerColumns\" *matHeaderCellDef>Role </mat-header-cell>\n            <mat-cell class=\"innerColumns\" *matCellDef=\"let user\">\n                <!--<input matInput placeholder=\"Endpoint Key\" [value]=\"user.role.roleName\" [(ngModel)]=\"user.role.roleName\">-->\n                <mat-select [(ngModel)]=\"user.role.id\" style=\"padding-left:5px\">\n                    <mat-option *ngFor=\"let role of roleList;let i = index\" [value]=\"role.id\">\n                        {{role.name}}\n                    </mat-option>\n                </mat-select>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"tutorialGroups\">\n            <mat-header-cell class=\"tutorialGroupColumn\" *matHeaderCellDef>Tutorial Groups </mat-header-cell>\n            <mat-cell class=\"tutorialGroupColumn\" *matCellDef=\"let user\">\n                <span class=\"link\" style=\"font-size: small;\" (click)=\"manageUserTutorial(user)\">{{user.tutorialGroupsString != undefined ? user.tutorialGroupsString : 'Click to manage user tutorial groups' }}</span>\n            </mat-cell>\n        </ng-container>\n\n        <ng-container matColumnDef=\"actions\">\n            <mat-header-cell class=\"lastColumn\" *matHeaderCellDef>&nbsp;Actions</mat-header-cell>\n            <mat-cell class=\"lastColumn\" *matCellDef=\"let user; let i = index;\">\n                <!--<button mat-button (click)=\"editRow(i)\"><mat-icon>edit</mat-icon></button>-->\n                <button mat-button (click)=\"deleteRow(user, i)\"><mat-icon>delete</mat-icon></button>\n                <button mat-button (click)=\"saveRow(user, i)\"><mat-icon>save</mat-icon></button>\n            </mat-cell>\n        </ng-container>\n\n\n        <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\n        <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\n    </mat-table>\n</div>\n\n<!--<p>\n    Bulk add/edit students by updating and uploading a .csv file. <br />\n</p>\n<p>\n    Download a template here\n    <a href=\"../../assets/StudentUploadTemplate.csv\">\n        <img src=\"../../assets/csvIcon.png\" width=\"32\" height=\"32\">\n    </a>\n</p>\n<div style=\"padding-bottom: 5px\">\n    <input id=\"studentFile\" type=\"file\" *ngIf=\"selectedCourseName != undefined\" (change)=\"handleFileInput($event.target)\" accept=\".csv\" #studentFile />\n</div>-->\n");

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/add-course-dialog/add-course-dialog.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/add-course-dialog/add-course-dialog.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkZC1jb3Vyc2UtZGlhbG9nL2FkZC1jb3Vyc2UtZGlhbG9nLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/add-course-dialog/add-course-dialog.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/add-course-dialog/add-course-dialog.component.ts ***!
  \******************************************************************/
/*! exports provided: AddCourseDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddCourseDialogComponent", function() { return AddCourseDialogComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var AddCourseDialogComponent = /** @class */ (function () {
    function AddCourseDialogComponent(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
    }
    AddCourseDialogComponent.prototype.ngOnInit = function () {
    };
    AddCourseDialogComponent.prototype.onOkClick = function () {
        this.dialogRef.close(this.selectedCourse);
    };
    AddCourseDialogComponent.prototype.onCancelClick = function () {
        this.dialogRef.close();
    };
    AddCourseDialogComponent.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"],] }] }
    ]; };
    AddCourseDialogComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-add-course-dialog',
            template: __importDefault(__webpack_require__(/*! raw-loader!./add-course-dialog.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-course-dialog/add-course-dialog.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./add-course-dialog.component.scss */ "./src/app/add-course-dialog/add-course-dialog.component.scss")).default]
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], AddCourseDialogComponent);
    return AddCourseDialogComponent;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@media (max-width: 767px) {\n  /* On small screens, the nav menu spans the full width of the screen. Leave a space for it. */\n  .body-content {\n    padding-top: 50px;\n  }\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw2RkFBNkY7RUFDN0Y7SUFDRSxpQkFBaUI7RUFDbkI7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KSB7XG4gIC8qIE9uIHNtYWxsIHNjcmVlbnMsIHRoZSBuYXYgbWVudSBzcGFucyB0aGUgZnVsbCB3aWR0aCBvZiB0aGUgc2NyZWVuLiBMZWF2ZSBhIHNwYWNlIGZvciBpdC4gKi9cbiAgLmJvZHktY29udGVudCB7XG4gICAgcGFkZGluZy10b3A6IDUwcHg7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __importDefault(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")).default]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule, getBaseUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBaseUrl", function() { return getBaseUrl; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.service */ "./src/app/app.service.ts");
/* harmony import */ var _question_question_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./question/question.component */ "./src/app/question/question.component.ts");
/* harmony import */ var _navmenu_navmenu_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./navmenu/navmenu.component */ "./src/app/navmenu/navmenu.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _config_config_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./config/config.component */ "./src/app/config/config.component.ts");
/* harmony import */ var _mystudents_mystudents_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./mystudents/mystudents.component */ "./src/app/mystudents/mystudents.component.ts");
/* harmony import */ var _tabcontrol_tabs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./tabcontrol/tabs */ "./src/app/tabcontrol/tabs.ts");
/* harmony import */ var _tabcontrol_tab__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./tabcontrol/tab */ "./src/app/tabcontrol/tab.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _courseadmin_courseadmin_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./courseadmin/courseadmin.component */ "./src/app/courseadmin/courseadmin.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _useradmin_useradmin_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./useradmin/useradmin.component */ "./src/app/useradmin/useradmin.component.ts");
/* harmony import */ var _generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./generic-dialog/generic-dialog.component */ "./src/app/generic-dialog/generic-dialog.component.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/cdk/table */ "./node_modules/@angular/cdk/esm5/table.es5.js");
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _add_course_dialog_add_course_dialog_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./add-course-dialog/add-course-dialog.component */ "./src/app/add-course-dialog/add-course-dialog.component.ts");
/* harmony import */ var _delete_course_dialog_delete_course_dialog_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./delete-course-dialog/delete-course-dialog.component */ "./src/app/delete-course-dialog/delete-course-dialog.component.ts");
/* harmony import */ var _course_provisioning_info_dialog_course_provisioning_info_dialog_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./course-provisioning-info-dialog/course-provisioning-info-dialog.component */ "./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.ts");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "./node_modules/@angular/cdk/esm5/drag-drop.es5.js");
/* harmony import */ var _tutorialadmin_tutorialadmin_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./tutorialadmin/tutorialadmin.component */ "./src/app/tutorialadmin/tutorialadmin.component.ts");
/* harmony import */ var _user_tutorial_dialog_user_tutorial_dialog_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./user-tutorial-dialog/user-tutorial-dialog.component */ "./src/app/user-tutorial-dialog/user-tutorial-dialog.component.ts");
/* harmony import */ var _silent_start_silent_start_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./silent-start/silent-start.component */ "./src/app/silent-start/silent-start.component.ts");
/* harmony import */ var _silent_end_silent_end_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./silent-end/silent-end.component */ "./src/app/silent-end/silent-end.component.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

































var appRoutes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: _home_home_component__WEBPACK_IMPORTED_MODULE_9__["HomeComponent"] },
    { path: 'question/:id', component: _question_question_component__WEBPACK_IMPORTED_MODULE_7__["QuestionComponent"], runGuardsAndResolvers: 'always' },
    { path: 'config', component: _config_config_component__WEBPACK_IMPORTED_MODULE_10__["ConfigComponent"] },
    { path: 'mystudents', component: _mystudents_mystudents_component__WEBPACK_IMPORTED_MODULE_11__["MyStudentsComponent"] },
    { path: 'courseadmin', component: _courseadmin_courseadmin_component__WEBPACK_IMPORTED_MODULE_15__["CourseadminComponent"] },
    { path: 'app-silent-start', component: _silent_start_silent_start_component__WEBPACK_IMPORTED_MODULE_29__["SilentStartComponent"] },
    { path: 'app-silent-end', component: _silent_end_silent_end_component__WEBPACK_IMPORTED_MODULE_30__["SilentEndComponent"] },
    { path: 'app-useradmin', component: _useradmin_useradmin_component__WEBPACK_IMPORTED_MODULE_18__["UserAdmin"] },
    { path: 'tutorialadmin', component: _tutorialadmin_tutorialadmin_component__WEBPACK_IMPORTED_MODULE_27__["TutorialAdminComponent"] },
    { path: 'courseinfo', component: _course_provisioning_info_dialog_course_provisioning_info_dialog_component__WEBPACK_IMPORTED_MODULE_25__["CourseProvisioningInfoDialogComponent"] },
    { path: '**', component: _home_home_component__WEBPACK_IMPORTED_MODULE_9__["HomeComponent"] }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_9__["HomeComponent"],
                _navmenu_navmenu_component__WEBPACK_IMPORTED_MODULE_8__["NavMenuComponent"],
                _question_question_component__WEBPACK_IMPORTED_MODULE_7__["QuestionComponent"],
                _config_config_component__WEBPACK_IMPORTED_MODULE_10__["ConfigComponent"],
                _mystudents_mystudents_component__WEBPACK_IMPORTED_MODULE_11__["MyStudentsComponent"],
                _tabcontrol_tabs__WEBPACK_IMPORTED_MODULE_12__["Tabs"],
                _tabcontrol_tab__WEBPACK_IMPORTED_MODULE_13__["Tab"],
                _courseadmin_courseadmin_component__WEBPACK_IMPORTED_MODULE_15__["CourseadminComponent"],
                _useradmin_useradmin_component__WEBPACK_IMPORTED_MODULE_18__["UserAdmin"],
                _generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_19__["GenericDialogComponent"],
                _add_course_dialog_add_course_dialog_component__WEBPACK_IMPORTED_MODULE_23__["AddCourseDialogComponent"],
                _delete_course_dialog_delete_course_dialog_component__WEBPACK_IMPORTED_MODULE_24__["DeleteCourseDialogComponent"],
                _course_provisioning_info_dialog_course_provisioning_info_dialog_component__WEBPACK_IMPORTED_MODULE_25__["CourseProvisioningInfoDialogComponent"],
                _tutorialadmin_tutorialadmin_component__WEBPACK_IMPORTED_MODULE_27__["TutorialAdminComponent"],
                _user_tutorial_dialog_user_tutorial_dialog_component__WEBPACK_IMPORTED_MODULE_28__["UserTutorialDialogComponent"],
                _silent_start_silent_start_component__WEBPACK_IMPORTED_MODULE_29__["SilentStartComponent"],
                _silent_end_silent_end_component__WEBPACK_IMPORTED_MODULE_30__["SilentEndComponent"]
            ],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"], ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_14__["Ng4LoadingSpinnerModule"].forRoot(),
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(appRoutes, { onSameUrlNavigation: 'reload' }),
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_16__["BrowserAnimationsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_17__["HttpClientModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_17__["HttpClientJsonpModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatDialogModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_22__["FontAwesomeModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatInputModule"],
                _angular_cdk_table__WEBPACK_IMPORTED_MODULE_21__["CdkTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_20__["MatListModule"],
                _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_26__["DragDropModule"]
            ],
            entryComponents: [_generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_19__["GenericDialogComponent"], _add_course_dialog_add_course_dialog_component__WEBPACK_IMPORTED_MODULE_23__["AddCourseDialogComponent"], _delete_course_dialog_delete_course_dialog_component__WEBPACK_IMPORTED_MODULE_24__["DeleteCourseDialogComponent"], _user_tutorial_dialog_user_tutorial_dialog_component__WEBPACK_IMPORTED_MODULE_28__["UserTutorialDialogComponent"]],
            providers: [{ provide: 'BASE_URL', useFactory: getBaseUrl }, _app_service__WEBPACK_IMPORTED_MODULE_6__["AppService"], _auth_service__WEBPACK_IMPORTED_MODULE_31__["AuthService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());

function getBaseUrl() {
    return document.getElementsByTagName('base')[0].href;
}


/***/ }),

/***/ "./src/app/app.service.ts":
/*!********************************!*\
  !*** ./src/app/app.service.ts ***!
  \********************************/
/*! exports provided: AppService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppService", function() { return AppService; });
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var AppService = /** @class */ (function () {
    function AppService(http, baseUrl, authService) {
        this.authService = authService;
        this.http = http;
        this.baseUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiBaseUrl;
        this.setHeaders();
    }
    AppService.prototype.setHeaders = function () {
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_0__["Headers"]({
            'Content-Type': 'application/json',
            'X-Frame-Options': 'SAMEORIGIN',
            'Authorization': 'Bearer ' + this.authService.token
        });
        this.options = new _angular_http__WEBPACK_IMPORTED_MODULE_0__["RequestOptions"]({ headers: headers });
    };
    AppService.prototype.initializeBotService = function () {
        return this.http.post(this.baseUrl + 'InitializeBotService', "", this.options);
    };
    AppService.prototype.getUserAccess = function (upn) {
        return this.http.get(this.baseUrl + 'GetUserAccess?upn=' + upn, this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getUserByUpn = function (upn) {
        return this.http.post(this.baseUrl + 'GetUserByUpn', JSON.stringify(upn), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getAllQuestions = function (tenantId) {
        return this.http.post(this.baseUrl + 'GetAllQuestions', JSON.stringify(tenantId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getTeamGroupIdsWithQuestions = function (tenantId, upn) {
        return this.http.post(this.baseUrl + 'GetTeamGroupIdsWithQuestions', JSON.stringify({ tenantId: tenantId, upn: upn }), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getOwnedTeams = function (tenantId, upn) {
        return this.http.post(this.baseUrl + 'GetOwnedTeams', JSON.stringify({ tenantId: tenantId, upn: upn }), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getTeamGroupDetail = function (groupId) {
        return this.http.post(this.baseUrl + 'GetTeamGroupDetail', JSON.stringify(groupId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getTeamChannels = function (groupId) {
        return this.http.post(this.baseUrl + 'GetTeamChannels', JSON.stringify(groupId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getQuestionsByGroup = function (groupId) {
        return this.http.post(this.baseUrl + 'GetQuestionsByGroup', JSON.stringify(groupId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getQuestionsByTutorial = function (tenantId, code) {
        return this.http.post(this.baseUrl + 'GetQuestionsByTutorial', JSON.stringify({ tenantId: tenantId, code: code }), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getCourses = function () {
        return this.http.get(this.baseUrl + 'GetCourses', this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.saveCourse = function (course) {
        return this.http.post(this.baseUrl + 'SaveCourse', course, this.options) // to actually just call Bot api
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.deleteCourse = function (id) {
        return this.http.post(this.baseUrl + 'DeleteCourse', id, this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.addStudents = function (students) {
        return this.http.post(this.baseUrl + 'AddStudents', students, this.options) // to actually just call Bot api
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getPredictiveQnAThreshold = function () {
        return this.http.get(this.baseUrl + 'GetPredictiveQnAThreshold', this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.setPredictiveQnAThreshold = function (threshold) {
        return this.http.post(this.baseUrl + 'SetPredictiveQnAThreshold', JSON.stringify(threshold), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.searchAndGetTimeUrl = function (phrase) {
        return this.http.post(this.baseUrl + 'SearchAndGetTimeUrl', JSON.stringify(phrase), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getUserCourseRoleMappingsByCourse = function (courseId) {
        return this.http.post(this.baseUrl + 'GetUserCourseRoleMappingsByCourse', JSON.stringify(courseId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.deleteUserCourseRoleMapping = function (user) {
        return this.http.post(this.baseUrl + 'DeleteUserCourseRoleMapping', JSON.stringify(user), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.saveUserCourseRoleMapping = function (user) {
        return this.http.post(this.baseUrl + 'SaveUserCourseRoleMapping', JSON.stringify(user), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.refreshUsers = function (course) {
        return this.http.post(this.baseUrl + 'RefreshUsers', JSON.stringify(course), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getRoles = function () {
        return this.http.get(this.baseUrl + 'GetRoles', this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getTutorialsByCourse = function (courseId) {
        return this.http.post(this.baseUrl + 'GetTutorialsByCourse', JSON.stringify(courseId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.saveTutorial = function (tutorial) {
        return this.http.post(this.baseUrl + 'SaveTutorialGroup', tutorial, this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.deleteTutorial = function (tutorial) {
        return this.http.post(this.baseUrl + 'DeleteTutorialGroup', tutorial, this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.ctorParameters = function () { return [
        { type: _angular_http__WEBPACK_IMPORTED_MODULE_0__["Http"] },
        { type: String, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: ['BASE_URL',] }] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
    ]; };
    AppService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])('BASE_URL')),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_0__["Http"], String, _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])
    ], AppService);
    return AppService;
}());



/***/ }),

/***/ "./src/app/auth.service.ts":
/*!*********************************!*\
  !*** ./src/app/auth.service.ts ***!
  \*********************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! adal-angular/lib/adal */ "./node_modules/adal-angular/lib/adal.js");
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var AuthService = /** @class */ (function () {
    function AuthService() {
        this.showSignInButton = false;
        this.loggedIn = false;
        this.config = {
            clientId: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.clientId,
            tenant: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.tenantId,
            // redirectUri must be in the list of redirect URLs for the Azure AD app
            redirectUri: window.location.origin + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.redirectUri,
            cacheLocation: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.cacheLocation,
            navigateToLoginRequestUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.navigateToLoginRequestUrl,
            popUp: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUp,
            extraQueryParameters: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.extraQueryParameters,
            postLogoutRedirectUri: window.location.origin
        };
    }
    AuthService.prototype.onAuthUpdate = function (fn) {
        this.loadNav = fn;
    };
    AuthService.prototype.getToken = function () {
        console.log("getToken");
        var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(this.config);
        // try get cached token
        var token = context.getCachedToken(this.config.clientId);
        if (token) {
            // cache token success
            this.token = token;
            this.loggedIn = true;
            this.showSignInButton = false;
            console.log("token saved");
            this.loadNav();
        }
        else {
            console.log("no cachedToken");
            // No token, or token is expired
            var callback = (function (err1, idToken) {
                if (err1) {
                    // token renew fail
                    this.showSignInButton = true;
                    this.loggedIn = false;
                    console.log("renew fail: " + err1);
                }
                else {
                    // token renew success
                    this.token = idToken;
                    this.loggedIn = true;
                    this.showSignInButton = false;
                    console.log("renew success");
                    this.loadNav();
                }
            }).bind(this);
            context._renewIdToken(callback);
        }
    };
    AuthService.prototype.signOut = function () {
        var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(this.config);
        context.logOut();
    };
    AuthService.prototype.signIn = function () {
        // try get token from AAD
        var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(this.config);
        var signInSuccessCallback = (function (result) {
            // AuthenticationContext is a singleton
            var config = {
                clientId: this.config.clientId,
                tenant: this.config.tenantId,
                // redirectUri must be in the list of redirect URLs for the Azure AD app
                redirectUri: window.location.origin + this.config.redirectUri,
                cacheLocation: this.config.cacheLocation,
                navigateToLoginRequestUrl: this.config.navigateToLoginRequestUrl,
                extraQueryParameters: this.config.extraQueryParameters,
            };
            var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(config);
            var idToken = context.getCachedToken(config.clientId);
            if (idToken) {
                this.showSignInButton = false;
                this.loggedIn = true;
                this.token = idToken;
                console.log("auth success");
                this.loadNav();
            }
            else {
                this.loggedIn = false;
                this.showSignInButton = true;
                console.log("auth success but no token");
            }
            ;
        }).bind(this);
        var signInFailCallback = (function (reason) {
            this.loggedIn = false;
            this.showSignInButton = true;
            console.log("Login failed: " + reason);
            if (reason === "CancelledByUser" || reason === "FailedToOpenWindow") {
                console.log("Login was blocked by popup blocker or canceled by user.");
            }
        }).bind(this);
        var msTeamsAuthenticate = (function () {
            _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["authentication"].authenticate({
                url: window.location.origin + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUpUri,
                width: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUpWidth,
                height: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUpHeight,
                successCallback: signInSuccessCallback,
                failureCallback: signInFailCallback
            });
        });
        var acquireTokencallback = (function (err, idToken) {
            // no token
            if (err) {
                console.log("acquire token failed: " + err);
                //context.login();
                _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["initialize"](msTeamsAuthenticate);
            }
            else {
                this.showSignInButton = false;
                this.loggedIn = true;
                this.token = idToken;
                console.log("acquire token success");
                this.loadNav();
            }
        }).bind(this);
        context.acquireToken(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.instance, acquireTokencallback);
    };
    AuthService.prototype.onRenewSuccess = function (idToken) {
        // token renew success
        this.token = idToken;
        this.loggedIn = true;
        this.showSignInButton = false;
        console.log("renew success");
    };
    AuthService.prototype.onRenewFailure = function (err1) {
        // token renew fail
        this.showSignInButton = true;
        this.loggedIn = false;
        console.log("renew fail" + err1);
    };
    AuthService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/config/config.component.ts":
/*!********************************************!*\
  !*** ./src/app/config/config.component.ts ***!
  \********************************************/
/*! exports provided: ConfigComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigComponent", function() { return ConfigComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var ConfigComponent = /** @class */ (function () {
    function ConfigComponent() {
    }
    ConfigComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log('ngOnInit');
        // initialize teams
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["initialize"]();
        // get context
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["getContext"](function (context) {
            console.log('getContext');
            _this.setValidityState(true);
        });
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["settings"].registerOnSaveHandler(function (saveEvent) {
            // Calculate host dynamically to enable local debugging
            var host = "https://" + window.location.host;
            _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["settings"].setSettings({
                contentUrl: host + "/#/home",
                suggestedDisplayName: "Questions",
                removeUrl: host + "/remove",
                entityId: "1"
            });
            saveEvent.notifySuccess();
        });
    };
    ConfigComponent.prototype.setValidityState = function (val) {
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["settings"].setValidityState(val);
    };
    ConfigComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'config',
            template: __importDefault(__webpack_require__(/*! raw-loader!./config.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/config/config.component.html")).default
        }),
        __metadata("design:paramtypes", [])
    ], ConfigComponent);
    return ConfigComponent;
}());



/***/ }),

/***/ "./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.css":
/*!***********************************************************************************************!*\
  !*** ./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.css ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/deep/ .col-sm-3 {\n    display: none;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY291cnNlLXByb3Zpc2lvbmluZy1pbmZvLWRpYWxvZy9jb3Vyc2UtcHJvdmlzaW9uaW5nLWluZm8tZGlhbG9nLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0FBQ2pCIiwiZmlsZSI6InNyYy9hcHAvY291cnNlLXByb3Zpc2lvbmluZy1pbmZvLWRpYWxvZy9jb3Vyc2UtcHJvdmlzaW9uaW5nLWluZm8tZGlhbG9nLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvZGVlcC8gLmNvbC1zbS0zIHtcbiAgICBkaXNwbGF5OiBub25lO1xufVxuIl19 */");

/***/ }),

/***/ "./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.ts":
/*!**********************************************************************************************!*\
  !*** ./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.ts ***!
  \**********************************************************************************************/
/*! exports provided: CourseProvisioningInfoDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseProvisioningInfoDialogComponent", function() { return CourseProvisioningInfoDialogComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

//import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog'; // in case we need to inject data to this page later on
var CourseProvisioningInfoDialogComponent = /** @class */ (function () {
    function CourseProvisioningInfoDialogComponent() {
    }
    CourseProvisioningInfoDialogComponent.prototype.ngOnInit = function () { };
    CourseProvisioningInfoDialogComponent.prototype.onOKClick = function () {
        close();
    };
    CourseProvisioningInfoDialogComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-course-provisioning-info-dialog',
            template: __importDefault(__webpack_require__(/*! raw-loader!./course-provisioning-info-dialog.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./course-provisioning-info-dialog.component.css */ "./src/app/course-provisioning-info-dialog/course-provisioning-info-dialog.component.css")).default]
        }),
        __metadata("design:paramtypes", [])
    ], CourseProvisioningInfoDialogComponent);
    return CourseProvisioningInfoDialogComponent;
}());



/***/ }),

/***/ "./src/app/courseadmin/courseadmin.component.css":
/*!*******************************************************!*\
  !*** ./src/app/courseadmin/courseadmin.component.css ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n.k-link {\n    white-space: pre-line;\n    font-size: small;\n}\n\n.td {\n    font-size: smaller;\n}\n\n.k-command-cell {\n    display: flex;\n    padding-left: 5px !important;\n}\n\ntr {\n    white-space: pre;\n}\n\n.k-button k-grid-remove-command {\n    font-size: smaller;\n}\n\ninput.mat-input-element {\n    text-overflow: ellipsis;\n    font-size: small;\n    max-width: 50%;\n}\n\n.mat-header-cell {\n    font-size: 12px;\n    background-color: aliceblue;\n    padding-right: 5px;\n    /*text-align: center;*/\n    /*padding-left: 5px;*/\n}\n\n.mat-cell:first-of-type, mat-footer-cell:first-of-type, mat-header-cell:first-of-type {\n        padding-left: 12px !important;\n}\n\n.lastColumn {\n    max-width: 10%;\n}\n\n.mat-button {\n    min-width: 50px!important;\n}\n\n.link {\n    color: blue;\n    text-decoration: underline;\n    cursor: pointer;\n}\n\n/*mat-cell:last-of-type, mat-footer-cell:last-of-type, mat-header-cell:last-of-type {\n    flex:none;\n    padding-right:0!important;\n}*/\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY291cnNlYWRtaW4vY291cnNlYWRtaW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQ0E7SUFDSSxxQkFBcUI7SUFDckIsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksYUFBYTtJQUNiLDRCQUE0QjtBQUNoQzs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHVCQUF1QjtJQUN2QixnQkFBZ0I7SUFDaEIsY0FBYztBQUNsQjs7QUFFQTtJQUNJLGVBQWU7SUFDZiwyQkFBMkI7SUFDM0Isa0JBQWtCO0lBQ2xCLHNCQUFzQjtJQUN0QixxQkFBcUI7QUFDekI7O0FBRUE7UUFDUSw2QkFBNkI7QUFDckM7O0FBRUE7SUFDSSxjQUFjO0FBQ2xCOztBQUVBO0lBQ0kseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0ksV0FBVztJQUNYLDBCQUEwQjtJQUMxQixlQUFlO0FBQ25COztBQUNBOzs7RUFHRSIsImZpbGUiOiJzcmMvYXBwL2NvdXJzZWFkbWluL2NvdXJzZWFkbWluLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5rLWxpbmsge1xuICAgIHdoaXRlLXNwYWNlOiBwcmUtbGluZTtcbiAgICBmb250LXNpemU6IHNtYWxsO1xufVxuXG4udGQge1xuICAgIGZvbnQtc2l6ZTogc21hbGxlcjtcbn1cblxuLmstY29tbWFuZC1jZWxsIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBhZGRpbmctbGVmdDogNXB4ICFpbXBvcnRhbnQ7XG59XG5cbnRyIHtcbiAgICB3aGl0ZS1zcGFjZTogcHJlO1xufVxuXG4uay1idXR0b24gay1ncmlkLXJlbW92ZS1jb21tYW5kIHtcbiAgICBmb250LXNpemU6IHNtYWxsZXI7XG59XG5cbmlucHV0Lm1hdC1pbnB1dC1lbGVtZW50IHtcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICBmb250LXNpemU6IHNtYWxsO1xuICAgIG1heC13aWR0aDogNTAlO1xufVxuXG4ubWF0LWhlYWRlci1jZWxsIHtcbiAgICBmb250LXNpemU6IDEycHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYWxpY2VibHVlO1xuICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcbiAgICAvKnRleHQtYWxpZ246IGNlbnRlcjsqL1xuICAgIC8qcGFkZGluZy1sZWZ0OiA1cHg7Ki9cbn1cblxuLm1hdC1jZWxsOmZpcnN0LW9mLXR5cGUsIG1hdC1mb290ZXItY2VsbDpmaXJzdC1vZi10eXBlLCBtYXQtaGVhZGVyLWNlbGw6Zmlyc3Qtb2YtdHlwZSB7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMTJweCAhaW1wb3J0YW50O1xufVxuXG4ubGFzdENvbHVtbiB7XG4gICAgbWF4LXdpZHRoOiAxMCU7XG59XG5cbi5tYXQtYnV0dG9uIHtcbiAgICBtaW4td2lkdGg6IDUwcHghaW1wb3J0YW50O1xufVxuXG4ubGluayB7XG4gICAgY29sb3I6IGJsdWU7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuLyptYXQtY2VsbDpsYXN0LW9mLXR5cGUsIG1hdC1mb290ZXItY2VsbDpsYXN0LW9mLXR5cGUsIG1hdC1oZWFkZXItY2VsbDpsYXN0LW9mLXR5cGUge1xuICAgIGZsZXg6bm9uZTtcbiAgICBwYWRkaW5nLXJpZ2h0OjAhaW1wb3J0YW50O1xufSovXG4iXX0= */");

/***/ }),

/***/ "./src/app/courseadmin/courseadmin.component.ts":
/*!******************************************************!*\
  !*** ./src/app/courseadmin/courseadmin.component.ts ***!
  \******************************************************/
/*! exports provided: CourseadminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseadminComponent", function() { return CourseadminComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _add_course_dialog_add_course_dialog_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../add-course-dialog/add-course-dialog.component */ "./src/app/add-course-dialog/add-course-dialog.component.ts");
/* harmony import */ var _generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../generic-dialog/generic-dialog.component */ "./src/app/generic-dialog/generic-dialog.component.ts");
/* harmony import */ var _delete_course_dialog_delete_course_dialog_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../delete-course-dialog/delete-course-dialog.component */ "./src/app/delete-course-dialog/delete-course-dialog.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};









var CourseadminComponent = /** @class */ (function () {
    function CourseadminComponent(appService, dialog, router) {
        this.dialog = dialog;
        this.displayedColumns = ['courseName', 'predictiveQnAServiceHost', 'predictiveQnAKnowledgeBaseId', 'predictiveQnAEndpointKey',
            'predictiveQnAHttpEndpoint', 'predictiveQnAHttpKey', 'predictiveQnAKnowledgeBaseName', 'predictiveQnAConfidenceThreshold', 'deleteButton'];
        this.appService = appService;
        this.router = router;
    }
    CourseadminComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.appService.getCourses()
            .subscribe(function (courses) {
            _this.courses = courses;
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.courses);
        });
    };
    CourseadminComponent.prototype.editCourse = function (course) {
        if (course.id == 0) {
            alert("Please save this course first before editing.");
        }
        else {
            this.router.navigate(['usertutorialsetup/'], { queryParams: course });
        }
        console.log(course);
    };
    CourseadminComponent.prototype.addRow = function () {
        var _this = this;
        this.appService.getOwnedTeams(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].tid, src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].upn).subscribe(function (ownedTeams) {
            var teams = ownedTeams;
            teams.value.forEach(function (t, index, array) {
                _this.courses.forEach(function (c) {
                    if (t.displayName == c.name) {
                        array.splice(index, 1);
                    }
                });
            });
            //check against teams already in the table
            var dialogRef = _this.dialog.open(_add_course_dialog_add_course_dialog_component__WEBPACK_IMPORTED_MODULE_4__["AddCourseDialogComponent"], {
                width: '250px',
                data: teams.value
            });
            dialogRef.afterClosed().subscribe(function (res) {
                console.log("Dialog result: ", res);
                if (res) {
                    var newCourse = {
                        id: 0,
                        name: res.displayName,
                        predictiveQnAServiceHost: "",
                        predictiveQnAKnowledgeBaseId: "",
                        predictiveQnAEndpointKey: "",
                        predictiveQnAHttpEndpoint: "",
                        predictiveQnAHttpKey: "",
                        predictiveQnAKnowledgeBaseName: "",
                        predictiveQnAConfidenceThreshold: "",
                        deployedURL: "",
                        groupId: res.id,
                        edited: false
                    };
                    _this.courses.push(newCourse);
                    _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.courses);
                }
            });
        });
    };
    CourseadminComponent.prototype.deleteRow = function (row) {
        var _this = this;
        var courseToDeleteID = this.courses[row].id;
        var courseName = this.dataSource.data[row].name;
        var dialogRef = this.dialog.open(_delete_course_dialog_delete_course_dialog_component__WEBPACK_IMPORTED_MODULE_6__["DeleteCourseDialogComponent"], {
            width: '250px',
            data: { courseName: courseName, courseToDeleteID: courseToDeleteID }
        });
        dialogRef.afterClosed().subscribe(function (res) {
            console.log("Dialog result: ", res);
            if (res) {
                if (res > 0) {
                    _this.appService.deleteCourse(res)
                        .subscribe(function (courses) {
                        _this.courses = courses;
                        _this.courses.splice(row, 1);
                        _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.courses);
                    });
                }
                else {
                    _this.courses.splice(row, 1);
                    _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.courses);
                }
            }
        });
    };
    CourseadminComponent.prototype.saveRow = function (course) {
        var _this = this;
        this.appService.saveCourse(course)
            .subscribe(function (courses) {
            if (courses != null) { // api returns null if an exception is caught
                _this.openDialog("Success", "Courses successfully saved.");
            }
            else {
                _this.openDialog("Failure", "Courses were not saved, try again.");
            }
            _this.courses = courses;
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.courses);
        });
    };
    CourseadminComponent.prototype.openDialog = function (outcome, message) {
        var dialogRef = this.dialog.open(_generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_5__["GenericDialogComponent"], {
            width: '250px',
            data: { outcome: outcome, message: message }
        });
    };
    CourseadminComponent.ctorParameters = function () { return [
        { type: _app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] },
        { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('table', { static: false }),
        __metadata("design:type", Object)
    ], CourseadminComponent.prototype, "table", void 0);
    CourseadminComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'courseadmin',
            template: __importDefault(__webpack_require__(/*! raw-loader!./courseadmin.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/courseadmin/courseadmin.component.html")).default,
            encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
            styles: [__importDefault(__webpack_require__(/*! ./courseadmin.component.css */ "./src/app/courseadmin/courseadmin.component.css")).default]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]])
    ], CourseadminComponent);
    return CourseadminComponent;
}());



/***/ }),

/***/ "./src/app/delete-course-dialog/delete-course-dialog.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/delete-course-dialog/delete-course-dialog.component.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RlbGV0ZS1jb3Vyc2UtZGlhbG9nL2RlbGV0ZS1jb3Vyc2UtZGlhbG9nLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/delete-course-dialog/delete-course-dialog.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/delete-course-dialog/delete-course-dialog.component.ts ***!
  \************************************************************************/
/*! exports provided: DeleteCourseDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeleteCourseDialogComponent", function() { return DeleteCourseDialogComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var DeleteCourseDialogComponent = /** @class */ (function () {
    function DeleteCourseDialogComponent(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.courseData = data;
    }
    DeleteCourseDialogComponent.prototype.ngOnInit = function () {
    };
    DeleteCourseDialogComponent.prototype.onYesClick = function () {
        this.dialogRef.close(this.courseData.courseToDeleteID);
    };
    DeleteCourseDialogComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    DeleteCourseDialogComponent.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"],] }] }
    ]; };
    DeleteCourseDialogComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-delete-course-dialog',
            template: __importDefault(__webpack_require__(/*! raw-loader!./delete-course-dialog.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/delete-course-dialog/delete-course-dialog.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./delete-course-dialog.component.scss */ "./src/app/delete-course-dialog/delete-course-dialog.component.scss")).default]
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], DeleteCourseDialogComponent);
    return DeleteCourseDialogComponent;
}());



/***/ }),

/***/ "./src/app/generic-dialog/generic-dialog.component.css":
/*!*************************************************************!*\
  !*** ./src/app/generic-dialog/generic-dialog.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2dlbmVyaWMtZGlhbG9nL2dlbmVyaWMtZGlhbG9nLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/generic-dialog/generic-dialog.component.ts":
/*!************************************************************!*\
  !*** ./src/app/generic-dialog/generic-dialog.component.ts ***!
  \************************************************************/
/*! exports provided: GenericDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GenericDialogComponent", function() { return GenericDialogComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var GenericDialogComponent = /** @class */ (function () {
    function GenericDialogComponent(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
    }
    GenericDialogComponent.prototype.ngOnInit = function () { };
    GenericDialogComponent.prototype.onNoClick = function () {
        this.dialogRef.close();
    };
    GenericDialogComponent.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"],] }] }
    ]; };
    GenericDialogComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-generic-dialog',
            template: __importDefault(__webpack_require__(/*! raw-loader!./generic-dialog.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/generic-dialog/generic-dialog.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./generic-dialog.component.css */ "./src/app/generic-dialog/generic-dialog.component.css")).default]
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object])
    ], GenericDialogComponent);
    return GenericDialogComponent;
}());



/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};
/// <reference path='../../../node_modules/@types/adal/index.d.ts' />


var HomeComponent = /** @class */ (function () {
    function HomeComponent(authService) {
        this.authService = authService;
        this.title = 'app';
        this.isIframe = window !== window.parent && !window.opener;
        //alert("home");
        authService.getToken();
    }
    HomeComponent.prototype.SignIn = function (event) {
        this.authService.signIn();
    };
    HomeComponent.ctorParameters = function () { return [
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"] }
    ]; };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'home',
            template: __importDefault(__webpack_require__(/*! raw-loader!./home.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html")).default
        }),
        __metadata("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/mystudents/mystudents.component.css":
/*!*****************************************************!*\
  !*** ./src/app/mystudents/mystudents.component.css ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL215c3R1ZGVudHMvbXlzdHVkZW50cy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/mystudents/mystudents.component.ts":
/*!****************************************************!*\
  !*** ./src/app/mystudents/mystudents.component.ts ***!
  \****************************************************/
/*! exports provided: MyStudentsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyStudentsComponent", function() { return MyStudentsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var adaptivecards__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! adaptivecards */ "./node_modules/adaptivecards/lib/adaptivecards.js");
/* harmony import */ var adaptivecards__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(adaptivecards__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! markdown-it */ "./node_modules/markdown-it/index.js");
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(markdown_it__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment-timezone */ "./node_modules/moment-timezone/index.js");
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_5__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};






var MyStudentsComponent = /** @class */ (function () {
    function MyStudentsComponent(appService) {
        this.selectedTutorial = "ALL";
        this.appService = appService;
    }
    MyStudentsComponent.prototype.ngOnInit = function () {
        var _this = this;
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_2__["initialize"]();
        // get context
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_2__["getContext"](function (context) {
            _this.context = context;
            var tenantId = _this.context.tid;
            var currentUserEmail = _this.context.upn;
            _this.appService.getUserByUpn(currentUserEmail)
                .subscribe(function (user) {
                _this.currentUser = user;
            }, function (error) { return console.error(error); });
            _this.appService.getAllQuestions(tenantId)
                .subscribe(function (questions) {
                var cardHolderDiv;
                _this.questions = questions;
                _this.unansweredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "unanswered"; })
                    .sort(function (a, b) { return new Date(b.questionSubmitted).getTime() - new Date(a.questionSubmitted).getTime(); });
                _this.answeredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "answered"; })
                    .sort(function (a, b) { return new Date(b.questionAnswered).getTime() - new Date(a.questionAnswered).getTime(); });
                // create cards --- performance??
                /*** UNANSWERED ***/
                var unansweredFragment = document.createDocumentFragment();
                // iterate over questions
                if (_this.unansweredQuestions.length > 0) {
                    // iterate over questions
                    _this.unansweredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "unansweredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        unansweredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no unanswered questions.</div>";
                    unansweredFragment.appendChild(cardHolderDiv);
                }
                // And finally insert it somewhere in your page:
                document.getElementById("unansweredCardDiv").appendChild(unansweredFragment);
                /*** ANSWERED ***/
                var answeredFragment = document.createDocumentFragment();
                if (_this.answeredQuestions.length > 0) {
                    // iterate over questions
                    _this.answeredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "answeredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        answeredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no answered questions.</div>";
                    answeredFragment.appendChild(cardHolderDiv);
                }
                // And finally insert it somewhere in your page:
                document.getElementById("answeredCardDiv").appendChild(answeredFragment);
            }, function (error) { return console.error(error); });
        });
    };
    MyStudentsComponent.prototype.createCard = function (question) {
        var answerPosterName = "";
        if (question.answerPoster != null)
            answerPosterName = question.answerPoster.fullName;
        var cardUnanswered = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": question.topic,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.questionText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.answerText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium",
                                            "color": "good"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Submitted: ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": question.originalPoster.fullName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_5__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        var cardAnswered = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": question.topic,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.questionText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.answerText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium",
                                            "color": "good"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Submitted: ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": question.originalPoster.fullName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_5__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Answered:  ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": answerPosterName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_5__["utc"](question.questionAnswered).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        // Create an AdaptiveCard instance
        var adaptiveCard = new adaptivecards__WEBPACK_IMPORTED_MODULE_3__["AdaptiveCard"]();
        // Set its hostConfig property unless you want to use the default Host Config
        // Host Config defines the style and behavior of a card
        adaptiveCard.hostConfig = new adaptivecards__WEBPACK_IMPORTED_MODULE_3__["HostConfig"]({
            "choiceSetInputValueSeparator": ",",
            "supportsInteractivity": true,
            "fontFamily": "Segoe UI",
            "spacing": {
                "small": 3,
                "default": 8,
                "medium": 20,
                "large": 30,
                "extraLarge": 40,
                "padding": 20
            },
            "separator": {
                "lineThickness": 1,
                "lineColor": "#EEEEEE"
            },
            "fontSizes": {
                "small": 12,
                "default": 14,
                "medium": 17,
                "large": 21,
                "extraLarge": 26
            },
            "fontWeights": {
                "lighter": 200,
                "default": 400,
                "bolder": 600
            },
            "imageSizes": {
                "small": 40,
                "medium": 80,
                "large": 160
            },
            "containerStyles": {
                "default": {
                    "foregroundColors": {
                        "default": {
                            "default": "#333333",
                            "subtle": "#EE333333"
                        },
                        "dark": {
                            "default": "#000000",
                            "subtle": "#66000000"
                        },
                        "light": {
                            "default": "#FFFFFF",
                            "subtle": "#33000000"
                        },
                        "accent": {
                            "default": "#2E89FC",
                            "subtle": "#882E89FC"
                        },
                        "good": {
                            "default": "#54a254",
                            "subtle": "#DD54a254"
                        },
                        "warning": {
                            "default": "#e69500",
                            "subtle": "#DDe69500"
                        },
                        "attention": {
                            "default": "#cc3300",
                            "subtle": "#DDcc3300"
                        }
                    },
                    "backgroundColor": "#00000000"
                },
                "emphasis": {
                    "foregroundColors": {
                        "default": {
                            "default": "#333333",
                            "subtle": "#EE333333"
                        },
                        "dark": {
                            "default": "#000000",
                            "subtle": "#66000000"
                        },
                        "light": {
                            "default": "#FFFFFF",
                            "subtle": "#33000000"
                        },
                        "accent": {
                            "default": "#2E89FC",
                            "subtle": "#882E89FC"
                        },
                        "good": {
                            "default": "#54a254",
                            "subtle": "#DD54a254"
                        },
                        "warning": {
                            "default": "#e69500",
                            "subtle": "#DDe69500"
                        },
                        "attention": {
                            "default": "#cc3300",
                            "subtle": "#DDcc3300"
                        }
                    },
                    "backgroundColor": "#08000000"
                }
            },
            "actions": {
                "maxActions": 5,
                "spacing": "Default",
                "buttonSpacing": 10,
                "showCard": {
                    "actionMode": "Inline",
                    "inlineTopMargin": 16,
                    "style": "emphasis"
                },
                "preExpandSingleShowCardAction": false,
                "actionsOrientation": "Horizontal",
                "actionAlignment": "Right"
            },
            "adaptiveCard": {
                "allowCustomStyle": false
            },
            "imageSet": {
                "imageSize": "Medium",
                "maxImageHeight": 100
            },
            "factSet": {
                "title": {
                    "size": "Default",
                    "color": "Default",
                    "isSubtle": false,
                    "weight": "Bolder",
                    "warp": true
                },
                "value": {
                    "size": "Default",
                    "color": "Default",
                    "isSubtle": false,
                    "weight": "Default",
                    "warp": true
                },
                "spacing": 10
            } // More host config options
        });
        // Set the adaptive card's event handlers. onExecuteAction is invoked
        // whenever an action is clicked in the card
        adaptiveCard.onExecuteAction = function (action) {
            window.open(action.url, "_blank");
        };
        // For markdown support
        adaptivecards__WEBPACK_IMPORTED_MODULE_3__["AdaptiveCard"].onProcessMarkdown = function (text) { return markdown_it__WEBPACK_IMPORTED_MODULE_4__().render(text); };
        // Parse the card payload
        if (question.questionAnswered)
            adaptiveCard.parse(cardAnswered);
        else
            adaptiveCard.parse(cardUnanswered);
        // Render the card to an HTML element:
        var renderedCard = adaptiveCard.render();
        return renderedCard;
    };
    MyStudentsComponent.prototype.filterByCode = function (code) {
        var _this = this;
        this.selectedTutorial = code;
        if (code === "ALL") {
            this.appService.getAllQuestions(this.context.tid).subscribe(function (questions) {
                var cardHolderDiv;
                _this.questions = questions;
                _this.unansweredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "unanswered"; })
                    .sort(function (a, b) { return new Date(b.questionSubmitted).getTime() - new Date(a.questionSubmitted).getTime(); });
                _this.answeredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "answered"; })
                    .sort(function (a, b) { return new Date(b.questionAnswered).getTime() - new Date(a.questionAnswered).getTime(); });
                // create cards --- performance??
                /*** UNANSWERED ***/
                var unansweredFragment = document.createDocumentFragment();
                // iterate over questions
                if (_this.unansweredQuestions.length > 0) {
                    // iterate over questions
                    _this.unansweredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "unansweredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        unansweredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no unanswered questions.</div>";
                    unansweredFragment.appendChild(cardHolderDiv);
                }
                // Remove existing fragments
                var myUnansweredNode = document.getElementById("unansweredCardDiv");
                while (myUnansweredNode.firstElementChild) {
                    myUnansweredNode.removeChild(myUnansweredNode.firstElementChild);
                }
                // And finally insert it somewhere in your page:
                myUnansweredNode.appendChild(unansweredFragment);
                /*** ANSWERED ***/
                var answeredFragment = document.createDocumentFragment();
                if (_this.answeredQuestions.length > 0) {
                    // iterate over questions
                    _this.answeredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "answeredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        answeredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no answered questions.</div>";
                    answeredFragment.appendChild(cardHolderDiv);
                }
                // Remove existing fragments
                var myAnsweredNode = document.getElementById("answeredCardDiv");
                while (myAnsweredNode.firstElementChild) {
                    myAnsweredNode.removeChild(myAnsweredNode.firstElementChild);
                }
                // And finally insert it somewhere in your page:
                myAnsweredNode.appendChild(answeredFragment);
            }, function (error) { return console.error(error); });
        }
        else {
            this.appService.getQuestionsByTutorial(this.context.tid, code).subscribe(function (questions) {
                var cardHolderDiv;
                _this.questions = questions;
                _this.unansweredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "unanswered"; })
                    .sort(function (a, b) { return new Date(b.questionSubmitted).getTime() - new Date(a.questionSubmitted).getTime(); });
                _this.answeredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "answered"; })
                    .sort(function (a, b) { return new Date(b.questionAnswered).getTime() - new Date(a.questionAnswered).getTime(); });
                // create cards --- performance??
                /*** UNANSWERED ***/
                var unansweredFragment = document.createDocumentFragment();
                // iterate over questions
                if (_this.unansweredQuestions.length > 0) {
                    // iterate over questions
                    _this.unansweredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "unansweredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        unansweredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no unanswered questions.</div>";
                    unansweredFragment.appendChild(cardHolderDiv);
                }
                // Remove existing fragments
                var myUnansweredNode = document.getElementById("unansweredCardDiv");
                while (myUnansweredNode.firstElementChild) {
                    myUnansweredNode.removeChild(myUnansweredNode.firstElementChild);
                }
                // And finally insert it somewhere in your page:
                myUnansweredNode.appendChild(unansweredFragment);
                /*** ANSWERED ***/
                var answeredFragment = document.createDocumentFragment();
                if (_this.answeredQuestions.length > 0) {
                    // iterate over questions
                    _this.answeredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "answeredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        answeredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no answered questions.</div>";
                    answeredFragment.appendChild(cardHolderDiv);
                }
                // Remove existing fragments
                var myAnsweredNode = document.getElementById("answeredCardDiv");
                while (myAnsweredNode.firstElementChild) {
                    myAnsweredNode.removeChild(myAnsweredNode.firstElementChild);
                }
                // And finally insert it somewhere in your page:
                myAnsweredNode.appendChild(answeredFragment);
            }, function (error) { return console.error(error); });
        }
    };
    MyStudentsComponent.ctorParameters = function () { return [
        { type: _app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] }
    ]; };
    MyStudentsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'mystudents',
            template: __importDefault(__webpack_require__(/*! raw-loader!./mystudents.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/mystudents/mystudents.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./mystudents.component.css */ "./src/app/mystudents/mystudents.component.css")).default]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
    ], MyStudentsComponent);
    return MyStudentsComponent;
}());



/***/ }),

/***/ "./src/app/navmenu/navmenu.component.css":
/*!***********************************************!*\
  !*** ./src/app/navmenu/navmenu.component.css ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".glyphicon {\n    vertical-align: middle;\n    padding: 2px;\n    font-size: 28px;\n    color: #49494d;\n}\n\nli .glyphicon {\n    margin-right: 2px;\n}\n\nli.link-active {\n    display: flex;\n}\n\nli.link-active .glyphicon {\n        color: white !important\n    }\n\n/* Highlighting rules for nav menu items */\n\nli.link-active a,\n    li.link-active a:hover,\n    li.link-active a:focus {\n        background-color: #6364a7;\n        color: white !important;\n    }\n\n/* Keep the nav menu independent of scrolling and on top of other items */\n\n.main-nav {\n    position: fixed;\n    top: 0;\n    left: 0;\n    right: 0;\n    z-index: 1;\n}\n\n@media (min-width: 768px) {\n    /* On small screens, convert the nav menu to a vertical sidebar */\n    .main-nav {\n        height: 100%;\n        width: calc(20% - 20px);\n    }\n\n    .navbar {\n        border-radius: 0px;\n        border-width: 0px;\n        height: 100%;\n    }\n\n    .navbar-header {\n        float: none;\n    }\n\n        .navbar-header p:hover {\n            color: black\n        }\n\n    .navbar-brand {\n        color: black;\n        padding-left: 10px;\n        padding-top: 10px;\n    }\n\n    .navbar-collapse {\n        display: block;\n        border-top: 1px solid #444;\n        padding: 0px;\n    }\n\n    .navbar ul {\n        float: none;\n    }\n\n    .navbar li {\n        float: none;\n        font-size: 15px;\n        margin: 6px;\n    }\n\n        .navbar li a {\n            padding: 10px 16px;\n            border-radius: 4px;\n            color: black;\n        }\n\n    .navbar a {\n        /* If a menu item's text is too long, truncate it */\n        width: 100%;\n        white-space: nowrap;\n        overflow: hidden;\n        text-overflow: ellipsis;\n    }\n\n    .navbar-inverse {\n        background-color: #edebe9;\n        display: contents;\n    }\n\n\n}\n\n.navtext {\n    color: #49494d;\n}\n\n.ng-fa-icon {\n    padding-right: 10px;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbmF2bWVudS9uYXZtZW51LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxzQkFBc0I7SUFDdEIsWUFBWTtJQUNaLGVBQWU7SUFDZixjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksaUJBQWlCO0FBQ3JCOztBQUVBO0lBQ0ksYUFBYTtBQUNqQjs7QUFFSTtRQUNJO0lBQ0o7O0FBRUEsMENBQTBDOztBQUMxQzs7O1FBR0kseUJBQXlCO1FBQ3pCLHVCQUF1QjtJQUMzQjs7QUFFSix5RUFBeUU7O0FBQ3pFO0lBQ0ksZUFBZTtJQUNmLE1BQU07SUFDTixPQUFPO0lBQ1AsUUFBUTtJQUNSLFVBQVU7QUFDZDs7QUFFQTtJQUNJLGlFQUFpRTtJQUNqRTtRQUNJLFlBQVk7UUFDWix1QkFBdUI7SUFDM0I7O0lBRUE7UUFDSSxrQkFBa0I7UUFDbEIsaUJBQWlCO1FBQ2pCLFlBQVk7SUFDaEI7O0lBRUE7UUFDSSxXQUFXO0lBQ2Y7O1FBRUk7WUFDSTtRQUNKOztJQUVKO1FBQ0ksWUFBWTtRQUNaLGtCQUFrQjtRQUNsQixpQkFBaUI7SUFDckI7O0lBRUE7UUFDSSxjQUFjO1FBQ2QsMEJBQTBCO1FBQzFCLFlBQVk7SUFDaEI7O0lBRUE7UUFDSSxXQUFXO0lBQ2Y7O0lBRUE7UUFDSSxXQUFXO1FBQ1gsZUFBZTtRQUNmLFdBQVc7SUFDZjs7UUFFSTtZQUNJLGtCQUFrQjtZQUNsQixrQkFBa0I7WUFDbEIsWUFBWTtRQUNoQjs7SUFFSjtRQUNJLG1EQUFtRDtRQUNuRCxXQUFXO1FBQ1gsbUJBQW1CO1FBQ25CLGdCQUFnQjtRQUNoQix1QkFBdUI7SUFDM0I7O0lBRUE7UUFDSSx5QkFBeUI7UUFDekIsaUJBQWlCO0lBQ3JCOzs7QUFHSjs7QUFFQTtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxtQkFBbUI7QUFDdkIiLCJmaWxlIjoic3JjL2FwcC9uYXZtZW51L25hdm1lbnUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5nbHlwaGljb24ge1xuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gICAgcGFkZGluZzogMnB4O1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICBjb2xvcjogIzQ5NDk0ZDtcbn1cblxubGkgLmdseXBoaWNvbiB7XG4gICAgbWFyZ2luLXJpZ2h0OiAycHg7XG59XG5cbmxpLmxpbmstYWN0aXZlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xufVxuXG4gICAgbGkubGluay1hY3RpdmUgLmdseXBoaWNvbiB7XG4gICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50XG4gICAgfVxuXG4gICAgLyogSGlnaGxpZ2h0aW5nIHJ1bGVzIGZvciBuYXYgbWVudSBpdGVtcyAqL1xuICAgIGxpLmxpbmstYWN0aXZlIGEsXG4gICAgbGkubGluay1hY3RpdmUgYTpob3ZlcixcbiAgICBsaS5saW5rLWFjdGl2ZSBhOmZvY3VzIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzYzNjRhNztcbiAgICAgICAgY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4vKiBLZWVwIHRoZSBuYXYgbWVudSBpbmRlcGVuZGVudCBvZiBzY3JvbGxpbmcgYW5kIG9uIHRvcCBvZiBvdGhlciBpdGVtcyAqL1xuLm1haW4tbmF2IHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgei1pbmRleDogMTtcbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XG4gICAgLyogT24gc21hbGwgc2NyZWVucywgY29udmVydCB0aGUgbmF2IG1lbnUgdG8gYSB2ZXJ0aWNhbCBzaWRlYmFyICovXG4gICAgLm1haW4tbmF2IHtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICB3aWR0aDogY2FsYygyMCUgLSAyMHB4KTtcbiAgICB9XG5cbiAgICAubmF2YmFyIHtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMHB4O1xuICAgICAgICBib3JkZXItd2lkdGg6IDBweDtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cblxuICAgIC5uYXZiYXItaGVhZGVyIHtcbiAgICAgICAgZmxvYXQ6IG5vbmU7XG4gICAgfVxuXG4gICAgICAgIC5uYXZiYXItaGVhZGVyIHA6aG92ZXIge1xuICAgICAgICAgICAgY29sb3I6IGJsYWNrXG4gICAgICAgIH1cblxuICAgIC5uYXZiYXItYnJhbmQge1xuICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgICAgICAgcGFkZGluZy10b3A6IDEwcHg7XG4gICAgfVxuXG4gICAgLm5hdmJhci1jb2xsYXBzZSB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzQ0NDtcbiAgICAgICAgcGFkZGluZzogMHB4O1xuICAgIH1cblxuICAgIC5uYXZiYXIgdWwge1xuICAgICAgICBmbG9hdDogbm9uZTtcbiAgICB9XG5cbiAgICAubmF2YmFyIGxpIHtcbiAgICAgICAgZmxvYXQ6IG5vbmU7XG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgbWFyZ2luOiA2cHg7XG4gICAgfVxuXG4gICAgICAgIC5uYXZiYXIgbGkgYSB7XG4gICAgICAgICAgICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgIH1cblxuICAgIC5uYXZiYXIgYSB7XG4gICAgICAgIC8qIElmIGEgbWVudSBpdGVtJ3MgdGV4dCBpcyB0b28gbG9uZywgdHJ1bmNhdGUgaXQgKi9cbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgIH1cblxuICAgIC5uYXZiYXItaW52ZXJzZSB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlZGViZTk7XG4gICAgICAgIGRpc3BsYXk6IGNvbnRlbnRzO1xuICAgIH1cblxuXG59XG5cbi5uYXZ0ZXh0IHtcbiAgICBjb2xvcjogIzQ5NDk0ZDtcbn1cblxuLm5nLWZhLWljb24ge1xuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG59XG4iXX0= */");

/***/ }),

/***/ "./src/app/navmenu/navmenu.component.ts":
/*!**********************************************!*\
  !*** ./src/app/navmenu/navmenu.component.ts ***!
  \**********************************************/
/*! exports provided: NavMenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavMenuComponent", function() { return NavMenuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ng4-loading-spinner */ "./node_modules/ng4-loading-spinner/ng4-loading-spinner.umd.js");
/* harmony import */ var ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var NavMenuComponent = /** @class */ (function () {
    function NavMenuComponent(appService, router, authService, domSanitizer, spinnerService) {
        this.appService = appService;
        this.router = router;
        this.authService = authService;
        this.domSanitizer = domSanitizer;
        this.spinnerService = spinnerService;
        this.errorMessage = null;
        this.isDemonstrator = false;
        this.isLecturer = false;
        this.isAdmin = false;
        this.faChalkboardTeacher = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faChalkboardTeacher"];
        this.faUsers = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faUsers"];
        this.faUserPlus = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faUserPlus"];
        this.faCogs = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faCogs"];
        this.faSignInAlt = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faSignInAlt"];
        this.faSignOutAlt = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faSignOutAlt"];
        this.faUsersCog = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faUsersCog"];
        this.faUserFriends = _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faUserFriends"];
    }
    NavMenuComponent.prototype.ngOnInit = function () {
        src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn = this.GetParam("upn");
        src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid = this.GetParam("tid");
        if (src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn && src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid) {
            this.spinnerService.show();
            this.authService.onAuthUpdate(this.onAuthUpdate.bind(this));
        }
    };
    NavMenuComponent.prototype.onAuthUpdate = function () {
        var _this = this;
        this.appService.setHeaders();
        // Do any first-time initialisation (like bootstrapping the initial user)
        this.appService.initializeBotService().subscribe(function () {
            _this.populateNav();
        }, function (error) {
            _this.showError("There was an error initializing the Bot service", error);
            _this.spinnerService.hide();
        });
    };
    NavMenuComponent.prototype.populateNav = function () {
        var _this = this;
        var upn = src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn;
        var tid = src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid;
        var userFinished = false;
        var groupFinished = false;
        this.appService.getUserAccess(upn)
            .subscribe(function (userAccess) {
            _this.isAdmin = userAccess.isGlobalAdmin;
            _this.isLecturer = userAccess.isLecturer;
            _this.isDemonstrator = userAccess.isDemonstrator;
            // only hide spinner when both tasks are complete
            userFinished = true;
            if (groupFinished) {
                _this.spinnerService.hide();
            }
        }, function (error) {
            _this.showError("There was an error getting initial user access", error);
            _this.spinnerService.hide();
        });
        // this needs to change when we implement a solution for provisioning the bot for different teams.
        // since there are very few teams, this is acceptable but it is in no way scalable.
        this.appService.getTeamGroupIdsWithQuestions(tid, upn)
            .subscribe(function (groupIds) {
            _this.groupIds = groupIds.sort();
            var tgd = new Array();
            _this.groupIds.forEach(function (groupId) {
                _this.appService.getTeamGroupDetail(groupId).subscribe(function (group) {
                    group.safePhotoByteUrl = _this.domSanitizer.bypassSecurityTrustUrl("data:image/png;base64," + group.photoByteUrl);
                    tgd.push(group);
                    if (tgd.length == groupIds.length) {
                        _this.teamGroupDetail = tgd;
                        if (_this.router.routerState.snapshot.url.indexOf('home') >= 0) {
                            _this.router.navigate(['question/' + _this.teamGroupDetail[0].id], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
                        }
                        else if (_this.router.routerState.snapshot.url.indexOf('question') >= 0) {
                            var id = _this.router.routerState.snapshot.url.split('/')[2].split('?')[0];
                            _this.router.navigate(['question/' + id], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
                        }
                        else {
                            var root = _this.router.routerState.snapshot.url.split('/')[1].split('?')[0];
                            _this.router.navigate([root], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
                        }
                        // only hide spinner when both tasks are complete
                        groupFinished = true;
                        if (userFinished) {
                            _this.spinnerService.hide();
                        }
                    }
                }, function (error) {
                    _this.showError("There was an error getting group details", error);
                    _this.spinnerService.hide();
                });
            });
        }, function (error) {
            _this.showError("There was an error getting group details", error);
            _this.spinnerService.hide();
        });
    };
    NavMenuComponent.prototype.showError = function (errorMessage, error) {
        if (error === void 0) { error = null; }
        this.errorMessage = errorMessage + (error ? error : "");
    };
    NavMenuComponent.prototype.GetParam = function (name) {
        var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(decodeURIComponent(window.location.href));
        if (!results) {
            return null;
        }
        return results[1] || null;
    };
    NavMenuComponent.prototype.teamNav = function (teamId) {
        this.router.navigate(['question/' + teamId], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
    };
    NavMenuComponent.prototype.myStudentNav = function () {
        this.router.navigate(['mystudents/'], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
    };
    NavMenuComponent.prototype.courseAdminNav = function () {
        this.router.navigate(['courseadmin/'], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
    };
    NavMenuComponent.prototype.addStudentNav = function () {
        this.router.navigate(['app-useradmin/'], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
    };
    NavMenuComponent.prototype.tutorialAdminNav = function () {
        this.router.navigate(['tutorialadmin/'], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
    };
    NavMenuComponent.prototype.settingsNav = function () {
        this.router.navigate(['settings/'], { queryParams: { upn: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn, tid: src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid } });
    };
    NavMenuComponent.ctorParameters = function () { return [
        { type: _app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
        { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"] },
        { type: ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_3__["Ng4LoadingSpinnerService"] }
    ]; };
    NavMenuComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'nav-menu',
            template: __importDefault(__webpack_require__(/*! raw-loader!./navmenu.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/navmenu/navmenu.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./navmenu.component.css */ "./src/app/navmenu/navmenu.component.css")).default]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["DomSanitizer"],
            ng4_loading_spinner__WEBPACK_IMPORTED_MODULE_3__["Ng4LoadingSpinnerService"]])
    ], NavMenuComponent);
    return NavMenuComponent;
}());



/***/ }),

/***/ "./src/app/question/question.component.css":
/*!*************************************************!*\
  !*** ./src/app/question/question.component.css ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".dropdown {\n    height: 50px;\n}\n\n.filterButtonTeamsCustom {\n    margin-right:10px;\n}\n\n.filterCollapseButton {\n    background-color: #16233A;\n    opacity: 0.52;\n    color: white;\n    cursor: pointer;\n    padding: 18px;\n    width: 100%;\n    border: none;\n    text-align: left;\n    outline: none;\n    font-size: 15px;\n}\n\n.active, .filterCollapseButton:hover {\n        background-color: #16233A;\n        opacity:0.36;\n    }\n\n.filterCollapseContent {\n    overflow: hidden;\n    background-color: #edebe9;\n    padding: 18px;\n    width: 100%;\n}\n\n.plusminus{\n    float: right;\n}\n\n.filterButton {\n    float: right;\n}\n\n.table {\n    table-layout:fixed;\n    width:100%;\n}\n\n.table > .tr > .td {\n    word-wrap:break-word;\n}\n\n\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcXVlc3Rpb24vcXVlc3Rpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsYUFBYTtJQUNiLFlBQVk7SUFDWixlQUFlO0lBQ2YsYUFBYTtJQUNiLFdBQVc7SUFDWCxZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGFBQWE7SUFDYixlQUFlO0FBQ25COztBQUVJO1FBQ0kseUJBQXlCO1FBQ3pCLFlBQVk7SUFDaEI7O0FBRUo7SUFDSSxnQkFBZ0I7SUFDaEIseUJBQXlCO0lBQ3pCLGFBQWE7SUFDYixXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxvQkFBb0I7QUFDeEIiLCJmaWxlIjoic3JjL2FwcC9xdWVzdGlvbi9xdWVzdGlvbi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRyb3Bkb3duIHtcbiAgICBoZWlnaHQ6IDUwcHg7XG59XG5cbi5maWx0ZXJCdXR0b25UZWFtc0N1c3RvbSB7XG4gICAgbWFyZ2luLXJpZ2h0OjEwcHg7XG59XG5cbi5maWx0ZXJDb2xsYXBzZUJ1dHRvbiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE2MjMzQTtcbiAgICBvcGFjaXR5OiAwLjUyO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgcGFkZGluZzogMThweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBvdXRsaW5lOiBub25lO1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuICAgIC5hY3RpdmUsIC5maWx0ZXJDb2xsYXBzZUJ1dHRvbjpob3ZlciB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMxNjIzM0E7XG4gICAgICAgIG9wYWNpdHk6MC4zNjtcbiAgICB9XG5cbi5maWx0ZXJDb2xsYXBzZUNvbnRlbnQge1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VkZWJlOTtcbiAgICBwYWRkaW5nOiAxOHB4O1xuICAgIHdpZHRoOiAxMDAlO1xufVxuXG4ucGx1c21pbnVze1xuICAgIGZsb2F0OiByaWdodDtcbn1cblxuLmZpbHRlckJ1dHRvbiB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4udGFibGUge1xuICAgIHRhYmxlLWxheW91dDpmaXhlZDtcbiAgICB3aWR0aDoxMDAlO1xufVxuXG4udGFibGUgPiAudHIgPiAudGQge1xuICAgIHdvcmQtd3JhcDpicmVhay13b3JkO1xufVxuXG5cbiJdfQ== */");

/***/ }),

/***/ "./src/app/question/question.component.ts":
/*!************************************************!*\
  !*** ./src/app/question/question.component.ts ***!
  \************************************************/
/*! exports provided: QuestionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuestionComponent", function() { return QuestionComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var adaptivecards__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! adaptivecards */ "./node_modules/adaptivecards/lib/adaptivecards.js");
/* harmony import */ var adaptivecards__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(adaptivecards__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! markdown-it */ "./node_modules/markdown-it/index.js");
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(markdown_it__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment-timezone */ "./node_modules/moment-timezone/index.js");
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_5__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



//import * as $ from 'jquery';
//import 'datatables.net';
//import * as microsoftTeams from '@microsoft/teams-js';



var QuestionComponent = /** @class */ (function () {
    function QuestionComponent(appService, route, router) {
        var _this = this;
        this.filterContentVisible = false;
        this.plusminus_classname = "plusminus glyphicon glyphicon-plus-sign";
        this.topics = ["All"];
        this.selectedTopic = "All";
        this.answeredContentVisible = true;
        this.unansweredContentVisible = true;
        this.appService = appService;
        this.route = route;
        this.router = router;
        this.navigationSubscription = this.router.events.subscribe(function (e) {
            // If it is a NavigationEnd event re-initalise the component
            if (e instanceof _angular_router__WEBPACK_IMPORTED_MODULE_1__["NavigationEnd"]) {
                _this.loadQuestions();
            }
        });
    }
    QuestionComponent.prototype.ngOnInit = function () {
        console.log('ngOnInit');
    };
    QuestionComponent.prototype.ngOnDestroy = function () {
        if (this.navigationSubscription) {
            this.navigationSubscription.unsubscribe();
        }
    };
    QuestionComponent.prototype.loadQuestions = function () {
        var _this = this;
        try {
            this.groupId = this.route.snapshot.paramMap.get("id");
            console.log(this.groupId);
            this.appService.getTeamChannels(this.groupId)
                .subscribe(function (teamChannels) {
                var newTopics = new Array();
                newTopics.push("All");
                teamChannels.forEach(function (c) {
                    newTopics.push(c.displayName);
                });
                _this.topics = newTopics;
            });
            this.appService.getQuestionsByGroup(this.groupId)
                .subscribe(function (questions) {
                var cardHolderDiv;
                _this.questions = questions;
                _this.unansweredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "unanswered"; })
                    .sort(function (a, b) { return new Date(b.questionSubmitted).getTime() - new Date(a.questionSubmitted).getTime(); });
                _this.answeredQuestions = _this.questions
                    .filter(function (x) { return x.questionStatus.trim() == "answered"; })
                    .sort(function (a, b) { return new Date(b.questionAnswered).getTime() - new Date(a.questionAnswered).getTime(); });
                // create cards --- performance??
                /*** UNANSWERED ***/
                var unansweredFragment = document.createDocumentFragment();
                // iterate over questions
                if (_this.unansweredQuestions.length > 0) {
                    // iterate over questions
                    _this.unansweredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "unansweredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        unansweredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.setAttribute("class", "cardHolder");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no unanswered questions.</div>";
                    unansweredFragment.appendChild(cardHolderDiv);
                }
                // Remove existing fragments
                var myUnansweredNode = document.getElementById("unansweredCardDiv");
                while (myUnansweredNode.firstElementChild) {
                    myUnansweredNode.removeChild(myUnansweredNode.firstElementChild);
                }
                // And finally insert it somewhere in your page:
                myUnansweredNode.appendChild(unansweredFragment);
                /*** ANSWERED ***/
                var answeredFragment = document.createDocumentFragment();
                if (_this.answeredQuestions.length > 0) {
                    // iterate over questions
                    _this.answeredQuestions.forEach(function (q) {
                        cardHolderDiv = document.createElement("div");
                        cardHolderDiv.setAttribute("id", "answeredCardHolder");
                        cardHolderDiv.setAttribute("class", "cardHolder");
                        cardHolderDiv.appendChild(_this.createCard(q));
                        answeredFragment.appendChild(cardHolderDiv);
                    });
                }
                else {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no answered questions.</div>";
                    cardHolderDiv.setAttribute("class", "cardHolder");
                    answeredFragment.appendChild(cardHolderDiv);
                }
                // Remove existing fragments
                var myAnsweredNode = document.getElementById("answeredCardDiv");
                while (myAnsweredNode.firstElementChild) {
                    myAnsweredNode.removeChild(myAnsweredNode.firstElementChild);
                }
                // And finally insert it somewhere in your page:
                myAnsweredNode.appendChild(answeredFragment);
            }, function (error) { return console.error(error); });
            //});
        }
        catch (error) {
            console.error("try-catch: " + error);
        }
    };
    QuestionComponent.prototype.createCard = function (question) {
        var answerPosterName = "";
        if (question.answerPoster != null)
            answerPosterName = question.answerPoster.fullName;
        var cardUnanswered = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": question.topic,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.questionText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.answerText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium",
                                            "color": "good"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Submitted: ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": question.originalPoster.fullName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_5__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        var cardAnswered = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": question.topic,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.questionText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.answerText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium",
                                            "color": "good"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Submitted: ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": question.originalPoster.fullName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_5__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Answered:  ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": answerPosterName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_5__["utc"](question.questionAnswered).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        // Create an AdaptiveCard instance
        var adaptiveCard = new adaptivecards__WEBPACK_IMPORTED_MODULE_3__["AdaptiveCard"]();
        // Set its hostConfig property unless you want to use the default Host Config
        // Host Config defines the style and behavior of a card
        adaptiveCard.hostConfig = new adaptivecards__WEBPACK_IMPORTED_MODULE_3__["HostConfig"]({
            "choiceSetInputValueSeparator": ",",
            "supportsInteractivity": true,
            "fontFamily": "Segoe UI",
            "spacing": {
                "small": 3,
                "default": 8,
                "medium": 20,
                "large": 30,
                "extraLarge": 40,
                "padding": 20
            },
            "separator": {
                "lineThickness": 1,
                "lineColor": "#EEEEEE"
            },
            "fontSizes": {
                "small": 12,
                "default": 14,
                "medium": 17,
                "large": 21,
                "extraLarge": 26
            },
            "fontWeights": {
                "lighter": 200,
                "default": 400,
                "bolder": 600
            },
            "imageSizes": {
                "small": 40,
                "medium": 80,
                "large": 160
            },
            "containerStyles": {
                "default": {
                    "foregroundColors": {
                        "default": {
                            "default": "#333333",
                            "subtle": "#EE333333"
                        },
                        "dark": {
                            "default": "#000000",
                            "subtle": "#66000000"
                        },
                        "light": {
                            "default": "#FFFFFF",
                            "subtle": "#33000000"
                        },
                        "accent": {
                            "default": "#2E89FC",
                            "subtle": "#882E89FC"
                        },
                        "good": {
                            "default": "#54a254",
                            "subtle": "#DD54a254"
                        },
                        "warning": {
                            "default": "#e69500",
                            "subtle": "#DDe69500"
                        },
                        "attention": {
                            "default": "#cc3300",
                            "subtle": "#DDcc3300"
                        }
                    },
                    "backgroundColor": "#00000000"
                },
                "emphasis": {
                    "foregroundColors": {
                        "default": {
                            "default": "#333333",
                            "subtle": "#EE333333"
                        },
                        "dark": {
                            "default": "#000000",
                            "subtle": "#66000000"
                        },
                        "light": {
                            "default": "#FFFFFF",
                            "subtle": "#33000000"
                        },
                        "accent": {
                            "default": "#2E89FC",
                            "subtle": "#882E89FC"
                        },
                        "good": {
                            "default": "#54a254",
                            "subtle": "#DD54a254"
                        },
                        "warning": {
                            "default": "#e69500",
                            "subtle": "#DDe69500"
                        },
                        "attention": {
                            "default": "#cc3300",
                            "subtle": "#DDcc3300"
                        }
                    },
                    "backgroundColor": "#08000000"
                }
            },
            "actions": {
                "maxActions": 5,
                "spacing": "Default",
                "buttonSpacing": 10,
                "showCard": {
                    "actionMode": "Inline",
                    "inlineTopMargin": 16,
                    "style": "emphasis"
                },
                "preExpandSingleShowCardAction": false,
                "actionsOrientation": "Horizontal",
                "actionAlignment": "Right"
            },
            "adaptiveCard": {
                "allowCustomStyle": false
            },
            "imageSet": {
                "imageSize": "Medium",
                "maxImageHeight": 100
            },
            "factSet": {
                "title": {
                    "size": "Default",
                    "color": "Default",
                    "isSubtle": false,
                    "weight": "Bolder",
                    "warp": true
                },
                "value": {
                    "size": "Default",
                    "color": "Default",
                    "isSubtle": false,
                    "weight": "Default",
                    "warp": true
                },
                "spacing": 10
            } // More host config options
        });
        // Set the adaptive card's event handlers. onExecuteAction is invoked
        // whenever an action is clicked in the card
        adaptiveCard.onExecuteAction = function (action) {
            window.open(action.url, "_blank");
        };
        // For markdown support
        adaptivecards__WEBPACK_IMPORTED_MODULE_3__["AdaptiveCard"].onProcessMarkdown = function (text) { return markdown_it__WEBPACK_IMPORTED_MODULE_4__().render(text); };
        // Parse the card payload
        if (question.questionAnswered)
            adaptiveCard.parse(cardAnswered);
        else
            adaptiveCard.parse(cardUnanswered);
        // Render the card to an HTML element:
        var renderedCard = adaptiveCard.render();
        return renderedCard;
    };
    /*********** BUTTONS ***********/
    QuestionComponent.prototype.showHideUnanswered = function (event) {
        this.unansweredContentVisible = !this.unansweredContentVisible;
    };
    QuestionComponent.prototype.showHideAnswered = function (event) {
        this.answeredContentVisible = !this.answeredContentVisible;
    };
    QuestionComponent.prototype.showHideContent = function (event) {
        this.filterContentVisible = !this.filterContentVisible;
        if (this.filterContentVisible)
            this.plusminus_classname = "plusminus glyphicon glyphicon-minus-sign";
        else
            this.plusminus_classname = "plusminus glyphicon glyphicon-plus-sign";
    };
    QuestionComponent.prototype.applyFilters = function (event) {
        var _this = this;
        this.appService.getQuestionsByGroup(this.groupId)
            .subscribe(function (questions) {
            var postfilter = questions;
            if (_this.selectedTopic != "All")
                postfilter = postfilter.filter(function (q) { return q.topic.trim() == _this.selectedTopic.trim(); });
            //if (this.selectedStatus != "All") {
            //    console.log(this.selectedStatus.toLowerCase());
            //    console.log(postfilter[0]);
            //    postfilter = postfilter.filter(q => q.questionStatus.trim() == this.selectedStatus.toLowerCase().trim());
            //}
            _this.questions = postfilter;
            _this.unansweredQuestions = _this.questions
                .filter(function (x) { return x.questionStatus.trim() == "unanswered"; })
                .sort(function (a, b) { return new Date(b.questionSubmitted).getTime() - new Date(a.questionSubmitted).getTime(); });
            _this.answeredQuestions = _this.questions
                .filter(function (x) { return x.questionStatus.trim() == "answered"; })
                .sort(function (a, b) { return new Date(b.questionAnswered).getTime() - new Date(a.questionAnswered).getTime(); });
            // create cards --- performance??
            /*** UNANSWERED ***/
            var unansweredFragment = document.createDocumentFragment();
            var cardHolderDiv;
            if (_this.unansweredQuestions.length > 0) {
                // iterate over questions
                _this.unansweredQuestions.forEach(function (q) {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.setAttribute("id", "unansweredCardHolder");
                    cardHolderDiv.setAttribute("class", "cardHolder");
                    cardHolderDiv.appendChild(_this.createCard(q));
                    unansweredFragment.appendChild(cardHolderDiv);
                });
            }
            else {
                cardHolderDiv = document.createElement("div");
                cardHolderDiv.setAttribute("class", "cardHolder");
                cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no unanswered questions.</div>";
                unansweredFragment.appendChild(cardHolderDiv);
            }
            // Remove existing fragments
            var myUnansweredNode = document.getElementById("unansweredCardDiv");
            while (myUnansweredNode.firstElementChild) {
                myUnansweredNode.removeChild(myUnansweredNode.firstElementChild);
            }
            // And finally insert it somewhere in your page:
            myUnansweredNode.appendChild(unansweredFragment);
            /*** ANSWERED ***/
            var answeredFragment = document.createDocumentFragment();
            if (_this.answeredQuestions.length > 0) {
                // iterate over questions
                _this.answeredQuestions.forEach(function (q) {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.setAttribute("id", "answeredCardHolder");
                    cardHolderDiv.setAttribute("class", "cardHolder");
                    cardHolderDiv.appendChild(_this.createCard(q));
                    answeredFragment.appendChild(cardHolderDiv);
                });
            }
            else {
                cardHolderDiv = document.createElement("div");
                cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no answered questions.</div>";
                cardHolderDiv.setAttribute("class", "cardHolder");
                answeredFragment.appendChild(cardHolderDiv);
            }
            // Remove existing fragments
            var myAnsweredNode = document.getElementById("answeredCardDiv");
            while (myAnsweredNode.firstElementChild) {
                myAnsweredNode.removeChild(myAnsweredNode.firstElementChild);
            }
            // And finally insert it somewhere in your page:
            myAnsweredNode.appendChild(answeredFragment);
        }, function (error) { return console.error(error); });
    };
    QuestionComponent.prototype.resetFilters = function (event) {
        this.selectedTopic = "All";
        //this.selectedStatus = "All";
    };
    QuestionComponent.ctorParameters = function () { return [
        { type: _app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
    ]; };
    QuestionComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'question',
            template: __importDefault(__webpack_require__(/*! raw-loader!./question.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/question/question.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./question.component.css */ "./src/app/question/question.component.css")).default]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], QuestionComponent);
    return QuestionComponent;
}());



/***/ }),

/***/ "./src/app/silent-end/silent-end.component.scss":
/*!******************************************************!*\
  !*** ./src/app/silent-end/silent-end.component.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NpbGVudC1lbmQvc2lsZW50LWVuZC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/silent-end/silent-end.component.ts":
/*!****************************************************!*\
  !*** ./src/app/silent-end/silent-end.component.ts ***!
  \****************************************************/
/*! exports provided: SilentEndComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SilentEndComponent", function() { return SilentEndComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! expose-loader?AuthenticationContext!../../../node_modules/adal-angular/lib/adal.js */ "./node_modules/expose-loader/index.js?AuthenticationContext!./node_modules/adal-angular/lib/adal.js-exposed");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! adal-angular/lib/adal */ "./node_modules/adal-angular/lib/adal.js");
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

/// <reference path='../../../node_modules/@types/adal/index.d.ts' />


//let createAuthContextFn: adal.AuthenticationContextStatic = AuthenticationContext;


var SilentEndComponent = /** @class */ (function () {
    function SilentEndComponent() {
        //alert("silent end")
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["initialize"](function () {
            var config = {
                clientId: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.clientId,
                tenant: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.tenantId,
                // redirectUri must be in the list of redirect URLs for the Azure AD app
                redirectUri: window.location.origin + src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.redirectUri,
                cacheLocation: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.cacheLocation,
                navigateToLoginRequestUrl: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.navigateToLoginRequestUrl,
            };
            var authContext = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(config);
            if (authContext.isCallback(window.location.hash)) {
                authContext.handleWindowCallback();
                // Only call notifySuccess or notifyFailure if this page is in the authentication popup
                if (window.parent === window) {
                    if (authContext.getCachedUser()) {
                        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["authentication"].notifySuccess();
                    }
                    else {
                        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["authentication"].notifyFailure(authContext.getLoginError());
                    }
                }
            }
        });
        // ADAL.js configuration
    }
    SilentEndComponent.prototype.ngOnInit = function () {
    };
    SilentEndComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-silent-end',
            template: __importDefault(__webpack_require__(/*! raw-loader!./silent-end.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-end/silent-end.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./silent-end.component.scss */ "./src/app/silent-end/silent-end.component.scss")).default]
        }),
        __metadata("design:paramtypes", [])
    ], SilentEndComponent);
    return SilentEndComponent;
}());



/***/ }),

/***/ "./src/app/silent-start/silent-start.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/silent-start/silent-start.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NpbGVudC1zdGFydC9zaWxlbnQtc3RhcnQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/silent-start/silent-start.component.ts":
/*!********************************************************!*\
  !*** ./src/app/silent-start/silent-start.component.ts ***!
  \********************************************************/
/*! exports provided: SilentStartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SilentStartComponent", function() { return SilentStartComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! expose-loader?AuthenticationContext!../../../node_modules/adal-angular/lib/adal.js */ "./node_modules/expose-loader/index.js?AuthenticationContext!./node_modules/adal-angular/lib/adal.js-exposed");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! adal-angular/lib/adal */ "./node_modules/adal-angular/lib/adal.js");
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

/// <reference path='../../../node_modules/@types/adal/index.d.ts' />


//let createAuthContextFn: adal.AuthenticationContextStatic = AuthenticationContext;


var SilentStartComponent = /** @class */ (function () {
    function SilentStartComponent() {
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["initialize"]();
        // Get the tab context, and use the information to navigate to Azure AD login page
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["getContext"](function (context) {
            // ADAL.js configuration
            // Setup extra query parameters for ADAL
            // - openid and profile scope adds profile information to the id_token
            // - login_hint provides the expected user name
            var config = {
                clientId: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.clientId,
                tenant: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.tenantId,
                // redirectUri must be in the list of redirect URLs for the Azure AD app
                redirectUri: window.location.origin + src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.redirectUri,
                cacheLocation: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.cacheLocation,
                navigateToLoginRequestUrl: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.navigateToLoginRequestUrl,
                //popUp: true,
                extraQueryParameters: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.extraQueryParameters,
                displayCall: null
            };
            if (context.upn) {
                config.extraQueryParameters = "scope=openid+profile&login_hint=" + encodeURIComponent(context.upn);
            }
            else {
                config.extraQueryParameters = "scope=openid+profile";
            }
            // Use a custom displayCall function to add extra query parameters to the url before navigating to it
            config.displayCall = function (urlNavigate) {
                if (urlNavigate) {
                    if (config.extraQueryParameters) {
                        urlNavigate += "&" + config.extraQueryParameters;
                    }
                    window.location.replace(urlNavigate);
                }
            };
            // Navigate to the AzureAD login page        
            var authContext = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(config);
            authContext.login();
        });
    }
    SilentStartComponent.prototype.ngOnInit = function () {
    };
    SilentStartComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-silent-start',
            template: __importDefault(__webpack_require__(/*! raw-loader!./silent-start.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-start/silent-start.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./silent-start.component.scss */ "./src/app/silent-start/silent-start.component.scss")).default]
        }),
        __metadata("design:paramtypes", [])
    ], SilentStartComponent);
    return SilentStartComponent;
}());



/***/ }),

/***/ "./src/app/tabcontrol/tab.ts":
/*!***********************************!*\
  !*** ./src/app/tabcontrol/tab.ts ***!
  \***********************************/
/*! exports provided: Tab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab", function() { return Tab; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var Tab = /** @class */ (function () {
    function Tab() {
        this.active = false;
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('tabTitle'),
        __metadata("design:type", String)
    ], Tab.prototype, "title", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('tabActive'),
        __metadata("design:type", Object)
    ], Tab.prototype, "active", void 0);
    Tab = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tab',
            template: "\n    <div [hidden]=\"!active\" class=\"pane\" style=\"padding:0px;\">\n      <ng-content></ng-content>\n    </div>\n  ",
            styles: ["\n    .pane{\n      padding: 1em;\n    }\n  "]
        })
    ], Tab);
    return Tab;
}());



/***/ }),

/***/ "./src/app/tabcontrol/tabs.ts":
/*!************************************!*\
  !*** ./src/app/tabcontrol/tabs.ts ***!
  \************************************/
/*! exports provided: Tabs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tabs", function() { return Tabs; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _tab__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab */ "./src/app/tabcontrol/tab.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var Tabs = /** @class */ (function () {
    function Tabs() {
        this.changed = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    // contentChildren are set
    Tabs.prototype.ngAfterContentInit = function () {
        // get all active tabs
        //let activeTabs = this.tabs.filter((tab) => tab.active);
        //// if there is no active tab set, activate the first
        //if (activeTabs.length === 0) {
        //    this.selectTab(this.tabs.first);
        //}
    };
    Tabs.prototype.selectTab = function (tab) {
        // deactivate all tabs
        this.tabs.toArray().forEach(function (tab) { return tab.active = false; });
        // activate the tab the user has clicked on.
        tab.active = true;
        this.changed.emit(tab.title);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])('tabChanged'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], Tabs.prototype, "changed", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChildren"])(_tab__WEBPACK_IMPORTED_MODULE_1__["Tab"]),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], Tabs.prototype, "tabs", void 0);
    Tabs = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tabs',
            template: "\n    <ul class=\"nav nav-tabs\">\n      <li *ngFor=\"let tab of tabs\" (click)=\"selectTab(tab)\" [class.active]=\"tab.active\" style=\"padding-right:10px;\">\n        <a href=\"#\" onclick=\"return false;\">{{tab.title}}</a>\n      </li>\n    </ul>\n    <ng-content></ng-content>\n  ",
        })
    ], Tabs);
    return Tabs;
}());



/***/ }),

/***/ "./src/app/tutorialadmin/tutorialadmin.component.css":
/*!***********************************************************!*\
  !*** ./src/app/tutorialadmin/tutorialadmin.component.css ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/*.firstColumn, .lastColumn {\n    min-width: 25%;\n    max-width: 25%;\n    word-break: break-word;\n}\n\n.innerColumns {\n    padding-left: 5px;\n    max-width: 12.5%;\n    min-width: 12.5%;\n}\n\n.mat-cell:first-of-type, mat-footer-cell:first-of-type, mat-header-cell:first-of-type {\n    padding-left: 10px !important;\n}\n\n.mat-cell:last-of-type, mat-footer-cell:last-of-type, mat-header-cell:last-of-type {\n    padding-right: 0px !important;\n}*/\n.mat-cell:last-of-type, mat-footer-cell:last-of-type, mat-header-cell:last-of-type {\npadding-right: 0px !important;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdHV0b3JpYWxhZG1pbi90dXRvcmlhbGFkbWluLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQWtCRTtBQUNGO0FBQ0EsNkJBQTZCO0FBQzdCIiwiZmlsZSI6InNyYy9hcHAvdHV0b3JpYWxhZG1pbi90dXRvcmlhbGFkbWluLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKi5maXJzdENvbHVtbiwgLmxhc3RDb2x1bW4ge1xuICAgIG1pbi13aWR0aDogMjUlO1xuICAgIG1heC13aWR0aDogMjUlO1xuICAgIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XG59XG5cbi5pbm5lckNvbHVtbnMge1xuICAgIHBhZGRpbmctbGVmdDogNXB4O1xuICAgIG1heC13aWR0aDogMTIuNSU7XG4gICAgbWluLXdpZHRoOiAxMi41JTtcbn1cblxuLm1hdC1jZWxsOmZpcnN0LW9mLXR5cGUsIG1hdC1mb290ZXItY2VsbDpmaXJzdC1vZi10eXBlLCBtYXQtaGVhZGVyLWNlbGw6Zmlyc3Qtb2YtdHlwZSB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tYXQtY2VsbDpsYXN0LW9mLXR5cGUsIG1hdC1mb290ZXItY2VsbDpsYXN0LW9mLXR5cGUsIG1hdC1oZWFkZXItY2VsbDpsYXN0LW9mLXR5cGUge1xuICAgIHBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xufSovXG4ubWF0LWNlbGw6bGFzdC1vZi10eXBlLCBtYXQtZm9vdGVyLWNlbGw6bGFzdC1vZi10eXBlLCBtYXQtaGVhZGVyLWNlbGw6bGFzdC1vZi10eXBlIHtcbnBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xufVxuIl19 */");

/***/ }),

/***/ "./src/app/tutorialadmin/tutorialadmin.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/tutorialadmin/tutorialadmin.component.ts ***!
  \**********************************************************/
/*! exports provided: TutorialAdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TutorialAdminComponent", function() { return TutorialAdminComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../generic-dialog/generic-dialog.component */ "./src/app/generic-dialog/generic-dialog.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var TutorialAdminComponent = /** @class */ (function () {
    function TutorialAdminComponent(appService, dialog) {
        this.dialog = dialog;
        this.displayedColumns = ['tutorialcode', 'name', 'actions'];
        this.appService = appService;
    }
    TutorialAdminComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.appService.getCourses()
            .subscribe(function (courses) {
            _this.courseList = courses;
        });
    };
    TutorialAdminComponent.prototype.updateTutorialMappingTable = function (course) {
        var _this = this;
        console.log(course);
        this.appService.getTutorialsByCourse(course.id)
            .subscribe(function (tutorials) {
            console.log(tutorials);
            _this.selectedCourse = course;
            _this.tutorials = tutorials;
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.tutorials);
        });
    };
    TutorialAdminComponent.prototype.addRow = function () {
        var newTutorial = {
            id: 0,
            courseId: this.selectedCourse.id,
            code: "",
            name: ""
        };
        this.tutorials.push(newTutorial);
        this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](this.tutorials);
    };
    TutorialAdminComponent.prototype.deleteRow = function (tutorial, row) {
        var _this = this;
        var tutorialToDelete = tutorial;
        //const dialogRef = this.dialog.open(DeleteCourseDialogComponent, {
        //    width: '250px',
        //    data: { courseName: courseName, courseToDeleteID: tutorialToDelete }
        //});
        // dialogRef.afterClosed().subscribe(res => {
        //    console.log("Dialog result: ", res)
        //    if (res) {
        //if (res > 0) {
        this.appService.deleteTutorial(tutorialToDelete)
            .subscribe(function (tutorials) {
            _this.tutorials = tutorials;
            _this.tutorials.splice(row, 1);
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.tutorials);
        });
        // } else {
        //  this.courses.splice(row, 1);
        //  this.dataSource = new MatTableDataSource(this.courses);
        // }
        //   }
        // });
    };
    TutorialAdminComponent.prototype.saveRow = function (row) {
        var _this = this;
        //this.editService.save(course, isNew);
        var tutorial = this.tutorials[row];
        this.appService.saveTutorial(tutorial)
            .subscribe(function (tutorials) {
            if (tutorials != null) { // api returns null if an exception is caught
                _this.openDialog("Success", "Tutorials successfully saved.");
            }
            else {
                _this.openDialog("Failure", "Tutorials were not saved, try again.");
            }
            _this.tutorials = tutorials;
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.tutorials);
        });
    };
    TutorialAdminComponent.prototype.openDialog = function (outcome, message) {
        var dialogRef = this.dialog.open(_generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_3__["GenericDialogComponent"], {
            width: '250px',
            data: { outcome: outcome, message: message }
        });
    };
    TutorialAdminComponent.ctorParameters = function () { return [
        { type: _app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] },
        { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"] }
    ]; };
    TutorialAdminComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tutorialadmin',
            template: __importDefault(__webpack_require__(/*! raw-loader!./tutorialadmin.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tutorialadmin/tutorialadmin.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./tutorialadmin.component.css */ "./src/app/tutorialadmin/tutorialadmin.component.css")).default]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]])
    ], TutorialAdminComponent);
    return TutorialAdminComponent;
}());



/***/ }),

/***/ "./src/app/user-tutorial-dialog/user-tutorial-dialog.component.scss":
/*!**************************************************************************!*\
  !*** ./src/app/user-tutorial-dialog/user-tutorial-dialog.component.scss ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXItdHV0b3JpYWwtZGlhbG9nL3VzZXItdHV0b3JpYWwtZGlhbG9nLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/user-tutorial-dialog/user-tutorial-dialog.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/user-tutorial-dialog/user-tutorial-dialog.component.ts ***!
  \************************************************************************/
/*! exports provided: UserTutorialDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserTutorialDialogComponent", function() { return UserTutorialDialogComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/dialog */ "./node_modules/@angular/material/esm5/dialog.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var UserTutorialDialogComponent = /** @class */ (function () {
    function UserTutorialDialogComponent(dialogRef, data, formBuilder) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.formBuilder = formBuilder;
        this.tutorials = [];
        this.userTutorials = [];
        this.user = data.user;
        this.tutorials = data.tutorials;
        this.userTutorials = this.user.tutorialGroups;
        this.selectedTutorials = this.userTutorials;
        this.tutorialForm = this.formBuilder.group({
            tutorials: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](this.userTutorials)
        });
    }
    UserTutorialDialogComponent.prototype.ngOnInit = function () {
    };
    UserTutorialDialogComponent.prototype.onOkClick = function () {
        this.user.tutorialGroups = this.selectedTutorials;
        this.dialogRef.close(this.user);
    };
    UserTutorialDialogComponent.prototype.onCancelClick = function () {
        this.dialogRef.close();
    };
    UserTutorialDialogComponent.ctorParameters = function () { return [
        { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"] },
        { type: undefined, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"], args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"],] }] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] }
    ]; };
    UserTutorialDialogComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user-tutorial-dialog',
            template: __importDefault(__webpack_require__(/*! raw-loader!./user-tutorial-dialog.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/user-tutorial-dialog/user-tutorial-dialog.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./user-tutorial-dialog.component.scss */ "./src/app/user-tutorial-dialog/user-tutorial-dialog.component.scss")).default]
        }),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])),
        __metadata("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])
    ], UserTutorialDialogComponent);
    return UserTutorialDialogComponent;
}());



/***/ }),

/***/ "./src/app/useradmin/useradmin.component.css":
/*!***************************************************!*\
  !*** ./src/app/useradmin/useradmin.component.css ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".firstColumn {\n    min-width: 25%;\n    max-width: 25%;\n    word-break: break-word;\n}\n\n.lastColumn {\n    min-width: 15%;\n    max-width: 15%;\n    word-break: break-word;\n    justify-content: center;\n}\n\n.innerColumns {\n    padding-left: 5px;\n    max-width: 12.5%;\n    min-width: 12.5%;\n}\n\n.tutorialGroupColumn {\n    padding-left: 10px;\n    max-width: 22.5%;\n    min-width: 22.5%;\n}\n\n.mat-cell:first-of-type, mat-footer-cell:first-of-type, mat-header-cell:first-of-type {\n    padding-left: 10px !important;\n}\n\n.mat-cell:last-of-type, mat-footer-cell:last-of-type, mat-header-cell:last-of-type {\n    padding-right: 0px !important;\n}\n\n.link {\n    color: blue;\n    text-decoration: underline;\n    cursor: pointer;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcmFkbWluL3VzZXJhZG1pbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGNBQWM7SUFDZCxzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxjQUFjO0lBQ2QsY0FBYztJQUNkLHNCQUFzQjtJQUN0Qix1QkFBdUI7QUFDM0I7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksNkJBQTZCO0FBQ2pDOztBQUVBO0lBQ0ksNkJBQTZCO0FBQ2pDOztBQUVBO0lBQ0ksV0FBVztJQUNYLDBCQUEwQjtJQUMxQixlQUFlO0FBQ25CIiwiZmlsZSI6InNyYy9hcHAvdXNlcmFkbWluL3VzZXJhZG1pbi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZpcnN0Q29sdW1uIHtcbiAgICBtaW4td2lkdGg6IDI1JTtcbiAgICBtYXgtd2lkdGg6IDI1JTtcbiAgICB3b3JkLWJyZWFrOiBicmVhay13b3JkO1xufVxuXG4ubGFzdENvbHVtbiB7XG4gICAgbWluLXdpZHRoOiAxNSU7XG4gICAgbWF4LXdpZHRoOiAxNSU7XG4gICAgd29yZC1icmVhazogYnJlYWstd29yZDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmlubmVyQ29sdW1ucyB7XG4gICAgcGFkZGluZy1sZWZ0OiA1cHg7XG4gICAgbWF4LXdpZHRoOiAxMi41JTtcbiAgICBtaW4td2lkdGg6IDEyLjUlO1xufVxuXG4udHV0b3JpYWxHcm91cENvbHVtbiB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgIG1heC13aWR0aDogMjIuNSU7XG4gICAgbWluLXdpZHRoOiAyMi41JTtcbn1cblxuLm1hdC1jZWxsOmZpcnN0LW9mLXR5cGUsIG1hdC1mb290ZXItY2VsbDpmaXJzdC1vZi10eXBlLCBtYXQtaGVhZGVyLWNlbGw6Zmlyc3Qtb2YtdHlwZSB7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5tYXQtY2VsbDpsYXN0LW9mLXR5cGUsIG1hdC1mb290ZXItY2VsbDpsYXN0LW9mLXR5cGUsIG1hdC1oZWFkZXItY2VsbDpsYXN0LW9mLXR5cGUge1xuICAgIHBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xufVxuXG4ubGluayB7XG4gICAgY29sb3I6IGJsdWU7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xufVxuIl19 */");

/***/ }),

/***/ "./src/app/useradmin/useradmin.component.ts":
/*!**************************************************!*\
  !*** ./src/app/useradmin/useradmin.component.ts ***!
  \**************************************************/
/*! exports provided: UserAdmin */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserAdmin", function() { return UserAdmin; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../generic-dialog/generic-dialog.component */ "./src/app/generic-dialog/generic-dialog.component.ts");
/* harmony import */ var _user_tutorial_dialog_user_tutorial_dialog_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../user-tutorial-dialog/user-tutorial-dialog.component */ "./src/app/user-tutorial-dialog/user-tutorial-dialog.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var UserAdmin = /** @class */ (function () {
    function UserAdmin(appService, dialog) {
        var _this = this;
        this.dialog = dialog;
        this.displayedColumns = ['userName', 'firstName', 'lastName', 'role',
            'tutorialGroups', 'actions'];
        this.appService = appService;
        this.appService.getRoles().subscribe(function (roles) {
            _this.roleList = roles;
            console.log(_this.roleList);
        });
    }
    UserAdmin.prototype.ngOnInit = function () {
        var _this = this;
        this.appService.getCourses()
            .subscribe(function (courses) {
            _this.courseList = courses;
        });
    };
    UserAdmin.prototype.handleFileInput = function (input) {
        var _this = this;
        var files = input.files;
        if (files && files.length) {
            var fileToRead = files[0];
            var fileReader_1 = new FileReader();
            fileReader_1.onload = function () {
                var textFromFileLoaded = fileReader_1.result;
                var lines = textFromFileLoaded.split('\n');
                var count = 1;
                _this.studentsToAdd = [];
                lines.forEach(function (element) {
                    if (count == 1) { // the reader doesn't give a line count so I just skip the first one
                        count++;
                    }
                    else {
                        var line = element.split(',');
                        var student = {
                            studentID: line[0],
                            firstName: line[1],
                            lastName: line[2],
                            username: line[3],
                            email: line[4],
                            role: line[5],
                            courseName: _this.selectedCourseName,
                            tutorialGroupID: (line[6]) ? line[6].trim() : ''
                        };
                        if (student.firstName != undefined) // skip the last line
                            _this.studentsToAdd.push(student);
                    }
                });
                if (_this.studentsToAdd.length > 0) {
                    //call app service to add students
                    _this.appService.addStudents(_this.studentsToAdd).subscribe(function (students) {
                        if (students != null) { // api returns null if an exception is caught
                            _this.openDialog("Success", "Students successfully added/updated.");
                        }
                        else {
                            _this.openDialog("Failure", "Students were not added/updated. Please check your .csv file and try again.");
                        }
                    });
                }
            };
            fileReader_1.readAsText(fileToRead, "UTF-8");
            this.studentFile.nativeElement.value = "";
        }
    };
    UserAdmin.prototype.updateUserTable = function (course) {
        var _this = this;
        console.log(course);
        if (this.selectedCourse == undefined || course.name != this.selectedCourse.name) {
            this.selectedCourse = course;
            this.appService.getUserCourseRoleMappingsByCourse(course.id)
                .subscribe(function (users) {
                console.log(users);
                _this.userList = users;
                _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](users);
                _this.appService.getTutorialsByCourse(course.id)
                    .subscribe(function (tutorials) {
                    console.log(tutorials);
                    _this.tutorials = tutorials;
                });
            });
        }
    };
    UserAdmin.prototype.manageUserTutorial = function (user) {
        var _this = this;
        if (user.id == 0) {
            alert("Please save this user first before editing.");
        }
        else {
            var dialogRef = this.dialog.open(_user_tutorial_dialog_user_tutorial_dialog_component__WEBPACK_IMPORTED_MODULE_4__["UserTutorialDialogComponent"], {
                width: '500px',
                height: '700px',
                data: { user: user, tutorials: this.tutorials }
            });
            dialogRef.afterClosed().subscribe(function (res) {
                if (res) {
                    var index = _this.userList.findIndex(function (user) { return user.id == res.id; });
                    if (index > -1) {
                        var newTutString = "";
                        if (res.tutorialGroups.length > 0) {
                            for (var i = 0; i < res.tutorialGroups.length; i++) {
                                newTutString += res.tutorialGroups[i].code + ", ";
                            }
                            newTutString = newTutString.substring(0, newTutString.length - 2);
                        }
                        res.tutorialGroupsString = newTutString;
                        _this.userList[index] = res;
                        _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.userList);
                    }
                    console.log(res);
                }
            });
        }
        console.log(user);
    };
    UserAdmin.prototype.refreshUsers = function () {
        var _this = this;
        this.appService.refreshUsers(this.selectedCourse).subscribe(function (users) {
            console.log(users);
            if (users) {
                _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](users);
            }
        });
    };
    UserAdmin.prototype.deleteRow = function (user, index) {
        var _this = this;
        this.appService.deleteUserCourseRoleMapping(user)
            .subscribe(function (users) {
            _this.userList = users;
            _this.userList.splice(index, 1);
            _this.dataSource = new _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatTableDataSource"](_this.userList);
        });
    };
    UserAdmin.prototype.saveRow = function (user, index) {
        var _this = this;
        this.appService.saveUserCourseRoleMapping(user)
            .subscribe(function (users) {
            if (users != null) { // api returns null if an exception is caught
                _this.openDialog("Success", "User successfully saved.");
            }
            else {
                _this.openDialog("Failure", "User was not saved, try again.");
            }
            _this.refreshUsers();
        });
    };
    UserAdmin.prototype.openDialog = function (outcome, message) {
        var dialogRef = this.dialog.open(_generic_dialog_generic_dialog_component__WEBPACK_IMPORTED_MODULE_3__["GenericDialogComponent"], {
            width: '250px',
            data: { outcome: outcome, message: message }
        });
    };
    UserAdmin.ctorParameters = function () { return [
        { type: _app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] },
        { type: _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"] }
    ]; };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('studentFile', { static: false }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], UserAdmin.prototype, "studentFile", void 0);
    UserAdmin = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-useradmin',
            template: __importDefault(__webpack_require__(/*! raw-loader!./useradmin.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/useradmin/useradmin.component.html")).default,
            encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None,
            styles: [__importDefault(__webpack_require__(/*! ./useradmin.component.css */ "./src/app/useradmin/useradmin.component.css")).default]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"], _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"]])
    ], UserAdmin);
    return UserAdmin;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};
var environment = {
    production: false,
    apiBaseUrl: "https://qbotapidemo.azurewebsites.net/api/Request/",
    authConfig: {
        instance: "https://login.microsoftonline.com/",
        tenantId: "f986a5cc-1665-4eb1-a645-cc46521cfbf2",
        clientId: "f7e0fa26-6301-4fb0-bdc8-a692f2ae94ea",
        redirectUri: "/app-silent-end",
        cacheLocation: "localStorage",
        navigateToLoginRequestUrl: false,
        extraQueryParameters: "",
        popUp: true,
        popUpUri: "/app-silent-start",
        popUpWidth: 600,
        popUpHeight: 535
    },
    // do not populate the following:
    upn: "",
    tid: "",
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\CodeBase\QBot-master\QBot-master\Source\DashboardTabApp\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map